<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RedirectIfAuthenticated
{
    public function handle(Request $request, Closure $next, string ...$guards): Response
    {
        $guards = empty($guards) ? [null] : $guards;

        foreach ($guards as $guard) {
            if (Auth::guard($guard)->check()) {
                $user = Auth::user();
                return match ($user->role) {
                    'super_admin' => redirect()->route('admin.users.index'),
                    'teacher' => redirect()->route('teacher.dashboard'),
                    'parent' => redirect()->route('parent.dashboard'),
                    'student' => redirect()->route('student.home'),
                    default => redirect('/'),
                };
            }
        }

        return $next($request);
    }
}
