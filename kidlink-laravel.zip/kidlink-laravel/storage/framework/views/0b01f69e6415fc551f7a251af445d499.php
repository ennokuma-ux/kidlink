<?php if (isset($component)) { $__componentOriginalae5c3ca666306b3b2dcb109e55417bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-layout','data' => ['title' => __('errors.db_missing_title'),'tag' => __('errors.config_problem'),'heading' => __('errors.db_h1_missing_ext', ['ext' => $exception->extensionName()]),'homeClass' => 'btn-quiet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('error-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('errors.db_missing_title')),'tag' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('errors.config_problem')),'heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('errors.db_h1_missing_ext', ['ext' => $exception->extensionName()])),'home-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('btn-quiet')]); ?>
    <p>
        <?php echo __('errors.db_config_used', [
            'conn' => '<code>'.$exception->connection.'</code>',
            'ext' => '<code>'.$exception->extensionName().'</code>',
        ]); ?>

        <?php echo e(__('errors.db_queries_fail')); ?>

    </p>

    <h2><?php echo e(__('errors.currently_running')); ?></h2>
    <pre><?php echo e($exception->runningBinary()); ?>

PHP <?php echo e(PHP_VERSION); ?> &#183; PDO drivers: <?php echo e(implode(', ', $availableDrivers) ?: __('errors.none')); ?></pre>

    <h2><?php echo e(__('errors.how_to_fix')); ?></h2>
    <ol>
        <li>
            <?php echo __('errors.db_fix_launcher'); ?>

            <pre>serve.cmd</pre>
        </li>
        <?php if($suggested): ?>
            <li>
                <?php echo e(__('errors.db_fix_pick_binary', [
                    'ext' => '<code>'.$exception->extensionName().'</code>',
                    'version' => $suggested['version'],
                ])); ?>

                <pre>"<?php echo e($suggested['path']); ?>" artisan serve --port=8000</pre>
            </li>
        <?php endif; ?>
        <li>
            <?php echo e(__('errors.db_fix_check_runtime')); ?>

            <pre>php artisan env:doctor</pre>
        </li>
    </ol>

    <p class="muted">
        <?php echo __('errors.db_static_note', ['ext' => '<code>'.$exception->extensionName().'</code>']); ?>

    </p>

    <p class="muted">
        <?php echo __('errors.db_skip_flag_note'); ?>

    </p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9)): ?>
<?php $attributes = $__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9; ?>
<?php unset($__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae5c3ca666306b3b2dcb109e55417bc9)): ?>
<?php $component = $__componentOriginalae5c3ca666306b3b2dcb109e55417bc9; ?>
<?php unset($__componentOriginalae5c3ca666306b3b2dcb109e55417bc9); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/errors/missing-database-driver.blade.php ENDPATH**/ ?>