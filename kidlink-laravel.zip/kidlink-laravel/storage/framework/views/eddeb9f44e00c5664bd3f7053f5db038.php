<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>KidLink - <?php echo $__env->yieldContent('title', __('page.parent_dashboard')); ?></title>
    
    
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/tailwind.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chart.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/alpine.min.js')); ?>"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-[#faf8f3] font-sans antialiased">
    <div class="flex h-screen bg-[#faf8f3]">
        <?php echo $__env->make('components.parent_sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="flex-1 flex flex-col overflow-hidden md:ml-64">
            <header class="bg-white shadow-sm border-b border-[#ebe8e1] px-6 py-4">
                <div class="flex items-center justify-between">
                    <h1 class="text-2xl font-bold text-[#182438]"><?php echo $__env->yieldContent('page-title', __('page.dashboard')); ?></h1>
                    <div class="flex items-center gap-4">
                        <?php if (isset($component)) { $__componentOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lang_switcher','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lang_switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e)): ?>
<?php $attributes = $__attributesOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e; ?>
<?php unset($__attributesOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e)): ?>
<?php $component = $__componentOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e; ?>
<?php unset($__componentOriginal2c6f6a1f4acdf7871e5a6eed76d01a2e); ?>
<?php endif; ?>
                        <span class="text-sm text-[#5f6873]"><?php echo e(__('header.welcome', ['name' => auth()->user()->full_name])); ?></span>
                        <?php echo $__env->make('components.child_mode', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="bg-[#f05d56] hover:bg-[#e04942] text-white px-4 py-2 rounded-lg text-sm transition"><?php echo e(__('header.logout')); ?></button>
                        </form>
                    </div>
                </div>
            </header>
            <main class="flex-1 overflow-y-auto p-6">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal19737a51bfae7124ebbf6cd99387b232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19737a51bfae7124ebbf6cd99387b232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.session-keep-alive','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('session-keep-alive'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19737a51bfae7124ebbf6cd99387b232)): ?>
<?php $attributes = $__attributesOriginal19737a51bfae7124ebbf6cd99387b232; ?>
<?php unset($__attributesOriginal19737a51bfae7124ebbf6cd99387b232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19737a51bfae7124ebbf6cd99387b232)): ?>
<?php $component = $__componentOriginal19737a51bfae7124ebbf6cd99387b232; ?>
<?php unset($__componentOriginal19737a51bfae7124ebbf6cd99387b232); ?>
<?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php if(session('success')): ?>
    <script>Swal.fire({ icon: 'success', title: <?php echo json_encode(__('misc.success_title'), 15, 512) ?>, text: <?php echo json_encode(session('success'), 15, 512) ?>, timer: 3000, showConfirmButton: false });</script>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <script>Swal.fire({ icon: 'error', title: <?php echo json_encode(__('misc.oops_title'), 15, 512) ?>, text: <?php echo json_encode(session('error'), 15, 512) ?> });</script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/layouts/parent.blade.php ENDPATH**/ ?>