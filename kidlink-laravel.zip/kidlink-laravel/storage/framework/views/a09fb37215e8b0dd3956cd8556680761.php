﻿

<?php $__env->startSection('title', __('parent_ui.attendance_title')); ?>
<?php $__env->startSection('page-title', __('parent_ui.attendance_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(!$child): ?>
<div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg mb-6">
    <p class="text-yellow-700"><?php echo e(__('parent_ui.no_child_selected')); ?></p>
</div>
<?php else: ?>
<?php echo $__env->make('components.child_selector', ['children' => $children, 'child' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="mb-6">
    <h2 class="text-xl font-bold text-gray-800"><?php echo e(__('parent_ui.child_attendance', ['name' => $child->first_name])); ?></h2>
    <p class="text-gray-500 text-sm"><?php echo e($month->format('F Y')); ?></p>
</div>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-green-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_present')); ?></p>
        <p class="text-2xl font-bold text-green-600 mt-1"><?php echo e($present); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-red-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_absent')); ?></p>
        <p class="text-2xl font-bold text-red-500 mt-1"><?php echo e($absent); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-yellow-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_late')); ?></p>
        <p class="text-2xl font-bold text-yellow-500 mt-1"><?php echo e($late); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-blue-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_rate')); ?></p>
        <p class="text-2xl font-bold text-blue-500 mt-1"><?php echo e($rate); ?>%</p>
    </div>
</div>

<!-- Month Navigation -->
<div class="flex items-center gap-3 mb-6">
    <a href="?month=<?php echo e($month->copy()->subMonth()->format('Y-m')); ?>" class="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm font-semibold hover:border-orange-300 transition"><?php echo e(__('parent_ui.prev_month')); ?></a>
    <span class="text-sm font-bold text-gray-700"><?php echo e($month->format('F Y')); ?></span>
    <a href="?month=<?php echo e($month->copy()->addMonth()->format('Y-m')); ?>" class="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm font-semibold hover:border-orange-300 transition"><?php echo e(__('parent_ui.next_month')); ?></a>
</div>

<!-- Calendar Grid -->
<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-8">
    <div class="grid grid-cols-7 gap-2">
        <?php $__currentLoopData = [__('parent_ui.day_sun'), __('parent_ui.day_mon'), __('parent_ui.day_tue'), __('parent_ui.day_wed'), __('parent_ui.day_thu'), __('parent_ui.day_fri'), __('parent_ui.day_sat')]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="text-center text-xs font-bold text-gray-400 pb-2"><?php echo e($day); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php
        $firstDay = $month->copy()->startOfMonth()->dayOfWeek;
        $daysInMonth = $month->daysInMonth;
        ?>
        <?php for($i = 0; $i < $firstDay; $i++): ?>
        <div></div>
        <?php endfor; ?>
        <?php $__currentLoopData = $monthlyChart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $bg = match($day['status']) {
            'Present' => 'bg-green-100 text-green-700',
            'Absent' => 'bg-red-100 text-red-700',
            'Late' => 'bg-yellow-100 text-yellow-700',
            default => 'bg-gray-50 text-gray-400',
        };
        ?>
        <div class="text-center p-2 rounded-lg text-sm font-semibold <?php echo e($bg); ?>">
            <?php echo e($day['day']); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- Monthly Summary -->
<?php if(count($monthlySummary) > 0): ?>
<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
    <h3 class="text-lg font-bold text-gray-800 mb-4"><?php echo e(__('parent_ui.monthly_summary')); ?></h3>
    <?php $__currentLoopData = $monthlySummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="flex items-center gap-4 p-3 <?php echo e($loop->last ? '' : 'border-b border-gray-50'); ?>">
        <div class="w-24">
            <p class="text-sm font-semibold text-gray-700"><?php echo e($m['month']); ?></p>
        </div>
        <div class="flex-1">
            <div class="w-full bg-gray-100 rounded-full h-2">
                <div class="h-2 rounded-full bg-green-500" style="width: <?php echo e($m['rate']); ?>%"></div>
            </div>
        </div>
        <div class="text-right">
            <span class="text-sm font-bold text-gray-600"><?php echo e($m['rate']); ?>%</span>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/parent/attendance.blade.php ENDPATH**/ ?>