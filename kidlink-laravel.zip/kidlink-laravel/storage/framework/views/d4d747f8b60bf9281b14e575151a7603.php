<?php $__env->startSection('title', __('teacher.accounts_title')); ?>
<?php $__env->startSection('page-title', __('teacher.accounts_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-xl shadow-sm p-6 mb-6">
<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h2 class="text-xl font-bold text-[#182438]"><?php echo e(__('teacher.manage_accounts')); ?></h2>
            <p class="text-sm text-[#5f6873] mt-1"><?php echo e(__('teacher.manage_accounts_subtitle')); ?></p>
        </div>
        <div class="flex flex-wrap items-center gap-3 self-start md:self-auto">
            <div class="flex items-center gap-1 bg-[#f5f3ee] rounded-lg p-1">
                <button type="button" id="viewStudentsBtn" onclick="switchView('students')"
                    class="px-5 py-2 rounded-md text-sm font-semibold transition bg-[#ff8555] text-white">
                    <?php echo e(__('teacher.students')); ?>

                </button>
                <button type="button" id="viewParentsBtn" onclick="switchView('parents')"
                    class="px-5 py-2 rounded-md text-sm font-semibold transition text-[#5f6873] hover:text-[#182438]">
                    <?php echo e(__('teacher.parents')); ?>

                </button>
                <button type="button" id="viewArchivedBtn" onclick="switchView('archived')"
                    class="px-5 py-2 rounded-md text-sm font-semibold transition text-[#5f6873] hover:text-[#182438]">
                    <?php echo e(__('teacher.archived')); ?>

                    <?php if($archivedStudents->count() + $archivedParents->count() > 0): ?>
                        <span class="ml-1.5 px-1.5 py-0.5 rounded-full bg-[#ebe8e1] text-[#5f6873] text-xs"><?php echo e($archivedStudents->count() + $archivedParents->count()); ?></span>
                    <?php endif; ?>
                </button>
            </div>
            <div id="studentActions" class="flex flex-wrap gap-2">
                <button onclick="document.getElementById('addStudentModal').classList.remove('hidden')" class="bg-[#ff8555] hover:bg-[#f47548] text-white px-6 py-2.5 rounded-lg transition font-medium">
                    <?php echo e(__('teacher.add_student_plus')); ?>

                </button>
            </div>
            <div id="parentActions" class="flex flex-wrap gap-2" style="display:none">
                <button onclick="document.getElementById('addParentModal').classList.remove('hidden')" class="bg-[#258cc5] hover:bg-[#1e73a8] text-white px-6 py-2.5 rounded-lg transition font-medium">
                    <?php echo e(__('teacher.create_parent_plus')); ?>

                </button>
            </div>
        </div>
    </div>
    <div class="mt-4">
        <div class="relative">
            <span class="absolute left-3 top-1/2 -translate-y-1/2 text-[#8b949d]">⌕</span>
            <input type="text" id="studentSearch" placeholder="<?php echo e(__('teacher.search_accounts')); ?>" autocomplete="off"
                class="w-full md:w-80 pl-9 pr-4 py-2.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
        </div>
    </div>
</div>

<div id="studentsView">
<div class="bg-white rounded-xl shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-[#faf8f3]">
<tr>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.name')); ?></th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.age')); ?></th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.class')); ?></th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('student.hand_label')); ?></th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.parent')); ?></th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.enrolled')); ?></th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.status')); ?></th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.actions')); ?></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-[#ebe8e1]">
<?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $editPayload = [
                        'id' => $student->id,
                        'first_name' => $student->first_name,
                        'last_name' => $student->last_name,
                        'sex' => $student->sex,
                        'date_of_birth' => $student->date_of_birth?->format('Y-m-d'),
                        'address' => $student->address,
                        'class_name' => $student->class_name,
                        'dominant_hand' => $student->dominant_hand,
                        'parent_ids' => $student->parents->pluck('id')->all(),
                    ];
                ?>
                <tr class="hover:bg-[#faf8f3] transition">
                    <td class="px-6 py-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-[#ff8555] rounded-full flex items-center justify-center text-white font-bold text-sm">
                                <?php echo e(strtoupper(substr($student->first_name, 0, 1))); ?><?php echo e(strtoupper(substr($student->last_name, 0, 1))); ?>

                            </div>
                            <span class="font-medium text-[#182438]"><?php echo e($student->name); ?></span>
                        </div>
                    </td>
<td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->age); ?> <?php echo e(__('teacher.yrs')); ?></td>
                    <td class="px-6 py-4">
                        <span class="px-3 py-1 rounded-full text-xs font-semibold <?php echo e($student->class_name ? 'bg-[#fff0e6] text-[#ff8555]' : 'bg-[#ebe8e1] text-[#8b949d]'); ?>">
                            <?php echo e($student->class_name ?? __('teacher.unassigned')); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->handLabel()); ?></td>
                    <td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->parents->isEmpty() ? '—' : $student->parents->pluck('full_name')->implode(', ')); ?></td>
                    <td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->enrolled_date?->format('Y-m-d') ?? '—'); ?></td>
                    <td class="px-6 py-4 text-center">
                        <span class="px-3 py-1 rounded-full text-xs font-semibold <?php echo e($student->is_active ? 'bg-green-100 text-green-700' : 'bg-[#ebe8e1] text-[#5f6873]'); ?>">
                            <?php echo e($student->is_active ? __('teacher.active') : __('teacher.inactive')); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4">
                        <div class="flex items-center justify-center gap-2">
                            <button type="button" title="<?php echo e(__('teacher.edit')); ?>"
                                data-edit='<?php echo json_encode($editPayload, 15, 512) ?>'
                                class="edit-student-btn w-9 h-9 rounded-lg border border-[#ebe8e1] hover:bg-[#faf8f3] transition text-[#258cc5]">
                                ✎
                            </button>
                            <form method="POST" action="<?php echo e(route('teacher.accounts.toggle', $student)); ?>"
                                onsubmit="return confirm('<?php echo e(__('teacher.archive_student_confirm')); ?>')">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <button type="submit" title="<?php echo e(__('teacher.archive')); ?>"
                                    class="w-9 h-9 rounded-lg border border-[#ebe8e1] hover:bg-[#faf8f3] transition text-[#258cc5]">
                                    ⏸
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="px-6 py-12 text-center text-[#8b949d]"><?php echo e(__('teacher.no_students_found')); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>

<div id="parentsView" class="hidden">
    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-[#faf8f3]">
                    <tr>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.name')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.email')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.contact')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.children')); ?></th>
                        <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.status')); ?></th>
                        <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#ebe8e1]">
                    <?php $__empty_1 = true; $__currentLoopData = $activeParents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-[#faf8f3] transition">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 bg-[#258cc5] rounded-full flex items-center justify-center text-white font-bold text-sm">
                                    <?php echo e(strtoupper(substr($parent->first_name, 0, 1))); ?><?php echo e(strtoupper(substr($parent->last_name, 0, 1))); ?>

                                </div>
                                <span class="font-medium text-[#182438]"><?php echo e($parent->full_name); ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-[#5f6873]"><?php echo e($parent->email); ?></td>
                        <td class="px-6 py-4 text-[#5f6873]"><?php echo e($parent->contact ?? '—'); ?></td>
                        <td class="px-6 py-4">
                            <?php if($parent->children->isEmpty()): ?>
                                <span class="text-[#8b949d]">—</span>
                            <?php else: ?>
                                <span class="px-3 py-1 rounded-full text-xs font-semibold bg-[#fff0e6] text-[#ff8555]">
                                    <?php echo e($parent->children->count()); ?> <?php echo e(Str::plural('child', $parent->children->count())); ?>

                                </span>
                                <span class="ml-2 text-sm text-[#5f6873]"><?php echo e($parent->children->pluck('name')->implode(', ')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold <?php echo e($parent->is_active ? 'bg-green-100 text-green-700' : 'bg-[#ebe8e1] text-[#5f6873]'); ?>">
                                <?php echo e($parent->is_active ? __('teacher.active') : __('teacher.inactive')); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center justify-center gap-2">
                                <form method="POST" action="<?php echo e(route('teacher.accounts.parent.toggle', $parent)); ?>"
                                    onsubmit="return confirm('<?php echo e(__('teacher.archive_parent_confirm')); ?>')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <button type="submit" title="<?php echo e(__('teacher.archive')); ?>"
                                        class="w-9 h-9 rounded-lg border border-[#ebe8e1] hover:bg-[#faf8f3] transition text-[#258cc5]">
                                        ⏸
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="px-6 py-12 text-center text-[#8b949d]"><?php echo e(__('teacher.no_parent_accounts_found')); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="archivedView" class="hidden">
    <div class="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
        <div class="px-6 py-4 bg-[#faf8f3] border-b border-[#ebe8e1]">
            <h3 class="text-sm font-bold text-[#182438]"><?php echo e(__('teacher.archived_students')); ?></h3>
            <p class="text-xs text-[#5f6873] mt-0.5"><?php echo e(__('teacher.archived_students_desc')); ?></p>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-[#faf8f3]">
                    <tr>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.name')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.class')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('student.hand_label')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.parent')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.enrolled')); ?></th>
                        <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.status')); ?></th>
                        <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#ebe8e1]">
                    <?php $__empty_1 = true; $__currentLoopData = $archivedStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-[#faf8f3] transition">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 bg-[#c9ced6] rounded-full flex items-center justify-center text-white font-bold text-sm">
                                    <?php echo e(strtoupper(substr($student->first_name, 0, 1))); ?><?php echo e(strtoupper(substr($student->last_name, 0, 1))); ?>

                                </div>
                                <span class="font-medium text-[#5f6873]"><?php echo e($student->name); ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->class_name ?? '—'); ?></td>
                        <td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->handLabel()); ?></td>
                        <td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->parents->isEmpty() ? '—' : $student->parents->pluck('full_name')->implode(', ')); ?></td>
                        <td class="px-6 py-4 text-[#5f6873]"><?php echo e($student->enrolled_date?->format('Y-m-d') ?? '—'); ?></td>
                        <td class="px-6 py-4 text-center">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold bg-[#ebe8e1] text-[#5f6873]"><?php echo e(__('teacher.archived_badge')); ?></span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center justify-center">
                                <form method="POST" action="<?php echo e(route('teacher.accounts.toggle', $student)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <button type="submit" title="<?php echo e(__('teacher.restore')); ?>"
                                        class="w-9 h-9 rounded-lg border border-[#ebe8e1] hover:bg-[#faf8f3] transition text-green-600">
                                        ▶
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="px-6 py-12 text-center text-[#8b949d]"><?php echo e(__('teacher.no_archived_students')); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <div class="px-6 py-4 bg-[#faf8f3] border-b border-[#ebe8e1]">
            <h3 class="text-sm font-bold text-[#182438]"><?php echo e(__('teacher.archived_parent_accounts')); ?></h3>
            <p class="text-xs text-[#5f6873] mt-0.5"><?php echo e(__('teacher.archived_parent_accounts_desc')); ?></p>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-[#faf8f3]">
                    <tr>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.name')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.email')); ?></th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.children')); ?></th>
                        <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.status')); ?></th>
                        <th class="px-6 py-4 text-center text-sm font-semibold text-[#182438]"><?php echo e(__('teacher.actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#ebe8e1]">
                    <?php $__empty_1 = true; $__currentLoopData = $archivedParents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-[#faf8f3] transition">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 bg-[#c9ced6] rounded-full flex items-center justify-center text-white font-bold text-sm">
                                    <?php echo e(strtoupper(substr($parent->first_name, 0, 1))); ?><?php echo e(strtoupper(substr($parent->last_name, 0, 1))); ?>

                                </div>
                                <span class="font-medium text-[#5f6873]"><?php echo e($parent->full_name); ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-[#5f6873]"><?php echo e($parent->email); ?></td>
                        <td class="px-6 py-4 text-[#5f6873]">
                            <?php echo e($parent->children->isEmpty() ? '—' : $parent->children->count() . ' ' . Str::plural('child', $parent->children->count())); ?>

                        </td>
                        <td class="px-6 py-4 text-center">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold bg-[#ebe8e1] text-[#5f6873]"><?php echo e(__('teacher.archived_badge')); ?></span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center justify-center">
                                <form method="POST" action="<?php echo e(route('teacher.accounts.parent.toggle', $parent)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <button type="submit" title="<?php echo e(__('teacher.restore')); ?>"
                                        class="w-9 h-9 rounded-lg border border-[#ebe8e1] hover:bg-[#faf8f3] transition text-green-600">
                                        ▶
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-6 py-12 text-center text-[#8b949d]"><?php echo e(__('teacher.no_archived_parent_accounts')); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="addStudentModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-2xl p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-[#182438]"><?php echo e(__('teacher.add_student')); ?></h3>
            <button onclick="this.closest('#addStudentModal').classList.add('hidden')" class="text-[#8b949d] hover:text-[#5f6873] text-2xl">&times;</button>
        </div>
        <form method="POST" action="<?php echo e(route('teacher.accounts.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.first_name')); ?></label>
                    <input type="text" name="first_name" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.last_name')); ?></label>
                    <input type="text" name="last_name" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
<div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.sex')); ?></label>
                    <select name="sex" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                        <option value="Female"><?php echo e(__('teacher.female')); ?></option>
                        <option value="Male"><?php echo e(__('teacher.male')); ?></option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.date_of_birth')); ?></label>
                    <input type="date" name="date_of_birth" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.class')); ?></label>
                <select name="class_name" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    <option value=""><?php echo e(__('teacher.not_set')); ?></option>
                    <?php $__currentLoopData = \App\Models\Student::SECTIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($section); ?>"><?php echo e($section); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('student.hand_label')); ?></label>
                <select name="dominant_hand" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    <?php $__currentLoopData = \App\Models\Student::HANDS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hand); ?>" <?php if($hand === 'Not yet established'): echo 'selected'; endif; ?>><?php echo e(\App\Models\Student::handLabels()[$hand]); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.address')); ?></label>
                <input type="text" name="address" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.connect_parent_accounts')); ?></label>
                <div class="relative mb-2">
                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-[#8b949d]">⌕</span>
                    <input type="text" id="parentSearch" placeholder="<?php echo e(__('teacher.search_parents')); ?>" autocomplete="off"
                        class="w-full pl-9 pr-4 py-2 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none text-sm">
                </div>
                <div id="parentList" class="border border-[#ebe8e1] rounded-lg max-h-40 overflow-y-auto p-3 space-y-2">
                    <?php $__empty_1 = true; $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <label class="flex items-center gap-3 cursor-pointer hover:bg-[#faf8f3] px-2 py-1 rounded-lg transition parent-item">
                        <input type="checkbox" name="parent_ids[]" value="<?php echo e($parent->id); ?>" class="w-4 h-4 text-[#ff8555] rounded focus:ring-[#ff8555]">
                        <span class="text-sm text-[#5f6873] parent-label"><?php echo e($parent->full_name); ?> <span class="text-xs text-[#8b949d]">(<?php echo e($parent->email); ?>)</span></span>
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-[#8b949d] p-2"><?php echo e(__('teacher.no_parent_accounts_yet')); ?></p>
                    <?php endif; ?>
                </div>
                <p class="text-xs text-[#8b949d] mt-1"><?php echo e(__('teacher.tick_multiple_parents')); ?></p>
            </div>
            <div class="border-t border-[#ebe8e1] pt-4">
                <label class="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" name="create_login" id="createLoginToggle" class="w-5 h-5 text-[#ff8555] rounded focus:ring-[#ff8555]">
                    <span class="text-sm font-medium text-[#182438]"><?php echo e(__('teacher.create_login_account')); ?></span>
                </label>
            </div>
            <div id="loginFields" class="grid grid-cols-2 gap-4 hidden">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.login_email')); ?></label>
                    <input type="email" name="student_email" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none" placeholder="student@kidlink.test">
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.password')); ?></label>
                    <input type="password" name="student_password" minlength="8" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none" placeholder="<?php echo e(__('teacher.min_8_characters')); ?>">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.father_name')); ?></label>
                    <input type="text" name="father_name" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.mother_name')); ?></label>
                    <input type="text" name="mother_name" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
            <div class="flex justify-end gap-3 pt-4">
                <button type="button" onclick="this.closest('#addStudentModal').classList.add('hidden')" class="px-6 py-2.5 border border-[#ebe8e1] rounded-lg text-[#5f6873] hover:bg-[#faf8f3] transition"><?php echo e(__('teacher.cancel')); ?></button>
                <button type="submit" class="px-6 py-2.5 bg-[#ff8555] text-white rounded-lg hover:bg-[#f47548] transition font-medium"><?php echo e(__('teacher.add_student')); ?></button>
            </div>
</form>
    </div>
</div>

<div id="addParentModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-2xl p-8 w-full max-w-md">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-[#182438]"><?php echo e(__('teacher.create_parent_account')); ?></h3>
            <button onclick="this.closest('#addParentModal').classList.add('hidden')" class="text-[#8b949d] hover:text-[#5f6873] text-2xl">&times;</button>
        </div>
        <form method="POST" action="<?php echo e(route('teacher.parents.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.first_name')); ?></label>
                    <input type="text" name="first_name" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.last_name')); ?></label>
                    <input type="text" name="last_name" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.email')); ?></label>
                <input type="email" name="email" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.password')); ?></label>
                <input type="password" name="password" required minlength="8" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.contact_optional')); ?></label>
                <input type="text" name="contact" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div class="flex justify-end gap-3 pt-4">
                <button type="button" onclick="this.closest('#addParentModal').classList.add('hidden')" class="px-6 py-2.5 border border-[#ebe8e1] rounded-lg text-[#5f6873] hover:bg-[#faf8f3] transition"><?php echo e(__('teacher.cancel')); ?></button>
                <button type="submit" class="px-6 py-2.5 bg-[#258cc5] text-white rounded-lg hover:bg-[#1e73a8] transition font-medium"><?php echo e(__('teacher.create_parent')); ?></button>
            </div>
        </form>
    </div>
</div>

<div id="editStudentModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-2xl p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-[#182438]"><?php echo e(__('teacher.edit_student')); ?></h3>
            <button onclick="this.closest('#editStudentModal').classList.add('hidden')" class="text-[#8b949d] hover:text-[#5f6873] text-2xl">&times;</button>
        </div>
        <form method="POST" id="editStudentForm" class="space-y-4">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.first_name')); ?></label>
                    <input type="text" name="first_name" id="editSFirstName" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.last_name')); ?></label>
                    <input type="text" name="last_name" id="editSLastName" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.sex')); ?></label>
                    <select name="sex" id="editSSex" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                        <option value="Female"><?php echo e(__('teacher.female')); ?></option>
                        <option value="Male"><?php echo e(__('teacher.male')); ?></option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.date_of_birth')); ?></label>
                    <input type="date" name="date_of_birth" id="editSDOB" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.class')); ?></label>
                <select name="class_name" id="editSClass" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    <option value=""><?php echo e(__('teacher.not_set')); ?></option>
                    <?php $__currentLoopData = \App\Models\Student::SECTIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($section); ?>"><?php echo e($section); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('student.hand_label')); ?></label>
                <select name="dominant_hand" id="editSHand" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    <?php $__currentLoopData = \App\Models\Student::HANDS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hand); ?>" <?php if($hand === 'Not yet established'): echo 'selected'; endif; ?>><?php echo e(\App\Models\Student::handLabels()[$hand]); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.address')); ?></label>
                <input type="text" name="address" id="editSAddress" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('teacher.connect_parent_accounts')); ?></label>
                <div class="relative mb-2">
                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-[#8b949d]">⌕</span>
                    <input type="text" id="editParentSearch" placeholder="<?php echo e(__('teacher.search_parents')); ?>" autocomplete="off"
                        class="w-full pl-9 pr-4 py-2 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none text-sm">
                </div>
                <div id="editParentList" class="border border-[#ebe8e1] rounded-lg max-h-40 overflow-y-auto p-3 space-y-2">
                    <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-3 cursor-pointer hover:bg-[#faf8f3] px-2 py-1 rounded-lg transition parent-item">
                        <input type="checkbox" name="parent_ids[]" value="<?php echo e($parent->id); ?>" class="w-4 h-4 text-[#ff8555] rounded focus:ring-[#ff8555]">
                        <span class="text-sm text-[#5f6873] parent-label"><?php echo e($parent->full_name); ?> <span class="text-xs text-[#8b949d]">(<?php echo e($parent->email); ?>)</span></span>
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="text-xs text-[#8b949d] mt-1"><?php echo e(__('teacher.tick_multiple_parents')); ?></p>
            </div>
            <div class="flex justify-end gap-3 pt-4">
                <button type="button" onclick="this.closest('#editStudentModal').classList.add('hidden')" class="px-6 py-2.5 border border-[#ebe8e1] rounded-lg text-[#5f6873] hover:bg-[#faf8f3] transition"><?php echo e(__('teacher.cancel')); ?></button>
                <button type="submit" class="px-6 py-2.5 bg-[#ff8555] text-white rounded-lg hover:bg-[#f47548] transition font-medium"><?php echo e(__('teacher.save_changes')); ?></button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const createLoginToggle = document.getElementById('createLoginToggle');
const loginFields = document.getElementById('loginFields');

if (createLoginToggle && loginFields) {
    createLoginToggle.addEventListener('change', function () {
        loginFields.classList.toggle('hidden', !this.checked);
    });
}

const VIEWS = ['students', 'parents', 'archived'];

function currentView() {
    return VIEWS.find(v => !document.getElementById(v + 'View').classList.contains('hidden')) || 'students';
}

function filterActiveTable() {
    const input = document.getElementById('studentSearch');
    const search = (input ? input.value : '').toLowerCase().trim();
    document.querySelectorAll('#' + currentView() + 'View tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(search) ? '' : 'none';
    });
}

function switchView(view) {
    VIEWS.forEach(v => document.getElementById(v + 'View').classList.toggle('hidden', v !== view));

    const btnActive = 'px-5 py-2 rounded-md text-sm font-semibold transition bg-[#ff8555] text-white';
    const btnIdle = 'px-5 py-2 rounded-md text-sm font-semibold transition text-[#5f6873] hover:text-[#182438]';
    VIEWS.forEach(v => {
        document.getElementById('view' + v.charAt(0).toUpperCase() + v.slice(1) + 'Btn').className = v === view ? btnActive : btnIdle;
    });

    // Archiving lives on the live accounts; the archived list is restore-only.
    document.getElementById('studentActions').style.display = view === 'students' ? '' : 'none';
    document.getElementById('parentActions').style.display = view === 'parents' ? '' : 'none';

    const input = document.getElementById('studentSearch');
    if (input) input.value = '';
    VIEWS.forEach(v => {
        document.querySelectorAll('#' + v + 'View tbody tr').forEach(row => row.style.display = '');
    });
}

const searchInput = document.getElementById('studentSearch');

if (searchInput) {
    searchInput.addEventListener('input', filterActiveTable);
}

const parentSearch = document.getElementById('parentSearch');
const parentItems = document.querySelectorAll('.parent-item');

if (parentSearch) {
    parentSearch.addEventListener('input', function () {
        const search = this.value.toLowerCase().trim();
        parentItems.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(search) ? '' : 'none';
        });
    });
}

const editStudentModal = document.getElementById('editStudentModal');
const editStudentForm = document.getElementById('editStudentForm');

document.querySelectorAll('.edit-student-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        const d = JSON.parse(this.dataset.edit);

        document.getElementById('editSFirstName').value = d.first_name;
        document.getElementById('editSLastName').value = d.last_name;
        document.getElementById('editSSex').value = d.sex;
        document.getElementById('editSDOB').value = d.date_of_birth;
        document.getElementById('editSClass').value = d.class_name || '';
        document.getElementById('editSHand').value = d.dominant_hand || 'Not yet established';
        document.getElementById('editSAddress').value = d.address || '';

        editStudentForm.action = `${window.location.origin}/teacher/accounts/${d.id}/update`;

        const checked = new Set(d.parent_ids || []);
        editStudentForm.querySelectorAll('#editParentList input').forEach(cb => {
            cb.checked = checked.has(Number(cb.value));
        });
        document.getElementById('editParentSearch').value = '';
        editStudentForm.querySelectorAll('#editParentList .parent-item').forEach(item => item.style.display = '');

        editStudentModal.classList.remove('hidden');
    });
});

const editParentSearch = document.getElementById('editParentSearch');
if (editParentSearch) {
    editParentSearch.addEventListener('input', function () {
        const search = this.value.toLowerCase().trim();
        editStudentForm.querySelectorAll('#editParentList .parent-item').forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(search) ? '' : 'none';
        });
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/teacher/accounts.blade.php ENDPATH**/ ?>