<?php $__env->startSection('title', __('announcements.new_announcement')); ?>
<?php $__env->startSection('page-title', __('announcements.new_announcement_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-xl shadow-sm p-6 mb-6 max-w-3xl">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h2 class="text-xl font-bold text-[#182438]"><?php echo e(__('announcements.new_announcement')); ?></h2>
            <p class="text-sm text-[#5f6873] mt-1"><?php echo e(__('announcements.visible_to_every_teacher_and_parent')); ?></p>
        </div>
        <a href="<?php echo e(route('announcements.index')); ?>" class="border border-[#ebe8e1] hover:bg-[#faf8f3] text-[#5f6873] px-6 py-2.5 rounded-lg transition font-medium self-start md:self-auto">
            <?php echo e(__('announcements.cancel')); ?>

        </a>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm p-6 max-w-3xl">
    <form method="POST" action="<?php echo e(route('announcements.store')); ?>" class="space-y-6">
        <?php echo csrf_field(); ?>

        <div>
            <label for="title" class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('announcements.title')); ?> <span class="text-[#f05d56]">*</span></label>
            <input type="text" name="title" id="title" required maxlength="255"
                value="<?php echo e(old('title')); ?>"
                class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-[#f05d56] <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo e(__('announcements.short_headline_placeholder')); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-[#f05d56] mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="body" class="block text-sm font-medium text-[#182438] mb-2"><?php echo e(__('announcements.announcement')); ?> <span class="text-[#f05d56]">*</span></label>
            <textarea name="body" id="body" rows="8" required maxlength="5000"
                class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none resize-none <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-[#f05d56] <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo e(__('announcements.write_full_announcement_here')); ?>"><?php echo e(old('body')); ?></textarea>
            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-[#f05d56] mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex justify-end gap-3 pt-4 border-t border-[#ebe8e1]">
            <a href="<?php echo e(route('announcements.index')); ?>" class="px-6 py-2.5 border border-[#ebe8e1] rounded-lg text-[#5f6873] hover:bg-[#faf8f3] transition"><?php echo e(__('announcements.cancel')); ?></a>
            <button type="submit" class="px-6 py-2.5 bg-[#ff8555] text-white rounded-lg hover:bg-[#f47548] transition font-medium"><?php echo e(__('announcements.publish')); ?></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.announcements', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/announcements/create.blade.php ENDPATH**/ ?>