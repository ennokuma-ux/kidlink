﻿

<?php $__env->startSection('title', __('parent_ui.milestones_title')); ?>
<?php $__env->startSection('page-title', __('parent_ui.milestones_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(!$child): ?>
<div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg mb-6">
    <p class="text-yellow-700"><?php echo e(__('parent_ui.no_child_selected')); ?></p>
</div>
<?php else: ?>
<?php echo $__env->make('components.child_selector', ['children' => $children, 'child' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="mb-6">
    <h2 class="text-xl font-bold text-gray-800"><?php echo e(__('parent_ui.child_milestones', ['name' => $child->first_name])); ?></h2>
    <p class="text-gray-500 text-sm"><?php echo e(__('parent_ui.overall_prefix')); ?> <span class="font-bold"><?php echo e($overallPercentage); ?>%</span> <?php echo e(__('parent_ui.overall_suffix')); ?></p>
</div>

<!-- Domain Stats -->
<div class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
    <?php $__currentLoopData = $domainStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
        <p class="text-sm font-bold text-gray-700 mb-2"><?php echo e($domain); ?></p>
        <div class="flex items-center gap-2 mb-2">
            <span class="text-2xl font-bold" style="color: <?php echo e($stat['percentage'] >= 80 ? '#22c55e' : ($stat['percentage'] >= 50 ? '#3b82f6' : '#f97316')); ?>;"><?php echo e($stat['percentage']); ?>%</span>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-2">
            <div class="h-2 rounded-full" style="width: <?php echo e($stat['percentage']); ?>%; background: <?php echo e($stat['percentage'] >= 80 ? '#22c55e' : ($stat['percentage'] >= 50 ? '#3b82f6' : '#f97316')); ?>;"></div>
        </div>
        <p class="text-xs text-gray-400 mt-1"><?php echo e($stat['achieved']); ?>/<?php echo e($stat['total']); ?> <?php echo e(__('parent_ui.achieved_label')); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Domain Filter -->
<div class="flex flex-wrap gap-2 mb-6">
    <a href="?domain=all" class="px-4 py-2 rounded-lg text-sm font-semibold transition <?php echo e($domain === 'all' ? 'bg-orange-500 text-white' : 'bg-white text-gray-500 border border-gray-200 hover:border-orange-300'); ?>"><?php echo e(__('parent_ui.filter_all')); ?></a>
    <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="?domain=<?php echo e(urlencode($d)); ?>" class="px-4 py-2 rounded-lg text-sm font-semibold transition <?php echo e($domain === $d ? 'bg-orange-500 text-white' : 'bg-white text-gray-500 border border-gray-200 hover:border-orange-300'); ?>"><?php echo e($d); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Records -->
<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="flex items-center gap-4 p-4 <?php echo e($loop->last ? '' : 'border-b border-gray-50'); ?>">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold" style="background: <?php echo e($record->status === 'Achieved' ? '#dcfce7' : ($record->status === 'In Progress' ? '#dbeafe' : '#fee2e2')); ?>; color: <?php echo e($record->status === 'Achieved' ? '#16a34a' : ($record->status === 'In Progress' ? '#2563eb' : '#dc2626')); ?>;">
            <?php echo e($record->status === 'Achieved' ? '✓' : ($record->status === 'In Progress' ? '○' : '✗')); ?>

        </div>
        <div class="flex-1">
            <p class="text-sm font-semibold text-gray-700"><?php echo e($record->indicator ?? $record->domain); ?></p>
            <p class="text-xs text-gray-400"><?php echo e($record->domain); ?></p>
        </div>
        <span class="px-3 py-1 rounded-full text-xs font-bold" style="background: <?php echo e($record->status === 'Achieved' ? '#dcfce7' : ($record->status === 'In Progress' ? '#dbeafe' : '#fee2e2')); ?>; color: <?php echo e($record->status === 'Achieved' ? '#16a34a' : ($record->status === 'In Progress' ? '#2563eb' : '#dc2626')); ?>;">
            <?php echo e($record->status); ?>

        </span>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-gray-400 text-center py-8"><?php echo e(__('parent_ui.no_milestone_records')); ?></p>
    <?php endif; ?>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/parent/milestones.blade.php ENDPATH**/ ?>