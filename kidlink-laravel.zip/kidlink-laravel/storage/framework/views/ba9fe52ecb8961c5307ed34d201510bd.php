﻿

<?php $__env->startSection('title', __('teacher.eccd_title')); ?>
<?php $__env->startSection('page-title', __('teacher.eccd_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 bg-white rounded-xl shadow-sm p-6">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h3 class="text-lg font-semibold text-[#182438]"><?php echo e(__('teacher.eccd_heading')); ?></h3>
            <p class="text-sm text-[#5f6873] mt-1"><?php echo e(__('teacher.eccd_administer_note')); ?> <span class="font-medium text-[#ff8555]"><?php echo e(__('teacher.evaluation_number')); ?><?php echo e($evaluationNumber); ?></span></p>
        </div>
        <form method="GET" action="<?php echo e(route('teacher.eccd.index')); ?>" class="flex items-center gap-3">
            <select name="student_id" onchange="this.form.submit()"
                class="px-4 py-2.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none text-sm">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>" <?php echo e($selectedStudent && $selectedStudent->id === $s->id ? 'selected' : ''); ?>><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="hidden" name="evaluation" value="<?php echo e($evaluationNumber); ?>">
        </form>
    </div>
</div>

<?php if($selectedStudent): ?>
<div class="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
    <div class="bg-white rounded-xl shadow-sm p-6 border-l-4 border-[#ff8555]">
        <p class="text-[#5f6873] text-sm"><?php echo e(__('teacher.child_name')); ?></p>
        <p class="text-2xl font-bold text-[#182438]"><?php echo e($selectedStudent->name); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-6 border-l-4 border-[#258cc5]">
        <p class="text-[#5f6873] text-sm"><?php echo e(__('teacher.age')); ?></p>
        <p class="text-2xl font-bold text-[#182438]"><?php echo e($selectedStudent->age); ?> <?php echo e(__('teacher.yrs')); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-6 border-l-4 border-[#68b82f]">
        <p class="text-[#5f6873] text-sm"><?php echo e(__('teacher.parent')); ?></p>
        <p class="text-2xl font-bold text-[#182438]"><?php echo e($selectedStudent->parent->full_name ?? '—'); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-6 border-l-4 border-[#d9b348]">
        <p class="text-[#5f6873] text-sm"><?php echo e(__('teacher.overall_progress')); ?></p>
        <p class="text-2xl font-bold text-[#182438]">
            <?php echo e($records->flatten()->count() > 0 ? round($records->flatten()->where('status','Achieved')->count() / max($records->flatten()->count(),1) * 100) : 0); ?>%
        </p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
    <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between mb-3">
            <h4 class="font-semibold text-[#182438]"><?php echo e($labels['domains'][$domain] ?? $domain); ?></h4>
            <span class="text-sm font-bold text-[#ff8555]"><?php echo e($scores[$domain] ?? 0); ?>%</span>
        </div>
        <div class="w-full bg-[#ebe8e1] rounded-full h-2 mb-3">
            <div class="bg-gradient-to-r from-[#ff8555] to-[#f47548] h-2 rounded-full" style="width: <?php echo e(min($scores[$domain] ?? 0, 100)); ?>%"></div>
        </div>
        <p class="text-xs text-[#5f6873]"><?php echo e(__('teacher.expected')); ?> <?php echo e($expectedScores[$domain] ?? 0); ?>%</p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $domainRecords = $records->get($domain, collect()); ?>
<div class="bg-white rounded-xl shadow-sm overflow-hidden mb-8">
    <div class="px-6 py-4 bg-[#182438] text-white flex items-center justify-between">
        <div>
            <h3 class="font-semibold"><?php echo e($labels['domains'][$domain] ?? $domain); ?></h3>
            <p class="text-xs text-white/60"><?php echo e(__('teacher.evaluation_number')); ?><?php echo e($evaluationNumber); ?></p>
        </div>
        <div class="text-right">
            <p class="text-xs text-white/60"><?php echo e(__('teacher.score')); ?></p>
            <p class="text-xl font-bold"><?php echo e($scores[$domain] ?? 0); ?>%</p>
        </div>
    </div>
    <table class="w-full">
        <thead class="bg-[#faf8f3]">
            <tr>
                <th class="px-6 py-3 text-left text-sm font-semibold text-[#5f6873] w-10">#</th>
                <th class="px-6 py-3 text-left text-sm font-semibold text-[#5f6873]"><?php echo e(__('teacher.indicator')); ?></th>
                <th class="px-6 py-3 text-center text-sm font-semibold text-[#5f6873] w-64"><?php echo e(__('teacher.status')); ?></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-[#ebe8e1]">
            <?php $__empty_1 = true; $__currentLoopData = $domainRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-[#faf8f3] transition">
                <td class="px-6 py-4 text-[#5f6873]"><?php echo e($i + 1); ?></td>
                <td class="px-6 py-4 font-medium text-[#182438]"><?php echo e($labels['indicators'][$record->indicator] ?? $record->indicator); ?></td>
                <td class="px-6 py-4">
                    <form method="POST" action="<?php echo e(route('teacher.eccd.update')); ?>" class="flex items-center gap-2">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="student_id" value="<?php echo e($selectedStudent->id); ?>">
                        <input type="hidden" name="record_id" value="<?php echo e($record->id); ?>">
                        <input type="hidden" name="evaluation" value="<?php echo e($evaluationNumber); ?>">
                        <?php $__currentLoopData = ['Not Yet','In Progress','Achieved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="submit" name="status" value="<?php echo e($status); ?>"
                            class="px-3 py-1.5 rounded-full text-xs font-medium transition
                            <?php echo e($record->status === $status
                                ? ($status === 'Achieved' ? 'bg-[#68b82f] text-white' : ($status === 'In Progress' ? 'bg-[#d9b348] text-white' : 'bg-[#f05d56] text-white'))
                                : 'bg-[#ebe8e1] text-[#5f6873] hover:bg-[#e0dcd3]'); ?>">
                            <?php echo e(['Not Yet' => __('teacher.status_not_yet'), 'In Progress' => __('teacher.status_in_progress'), 'Achieved' => __('teacher.status_achieved')][$status]); ?>

                        </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="px-6 py-8 text-center text-[#5f6873]"><?php echo e(__('teacher.no_records_domain')); ?></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(count($recommendations) > 0): ?>
<div class="bg-white rounded-xl shadow-sm p-6">
    <h3 class="text-lg font-semibold text-[#182438] mb-4"><?php echo e(__('teacher.expert_recommendations')); ?></h3>
    <div class="space-y-3">
        <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-4 rounded-lg border
            <?php echo e($rec['severity'] === 'success' ? 'border-[#68b82f] bg-green-50' : ($rec['severity'] === 'warning' ? 'border-[#d9b348] bg-yellow-50' : 'border-[#f05d56] bg-red-50')); ?>">
            <p class="font-semibold text-[#182438] text-sm"><?php echo e($rec['title']); ?></p>
            <p class="text-sm text-[#5f6873] mt-1"><?php echo e($rec['message']); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>
<?php else: ?>
<div class="bg-white rounded-xl shadow-sm p-10 text-center">
    <p class="text-[#5f6873]"><?php echo e(__('teacher.no_students_assigned')); ?></p>
    <a href="<?php echo e(route('teacher.accounts.index')); ?>" class="inline-block mt-4 bg-[#ff8555] hover:bg-[#f47548] text-white px-6 py-2.5 rounded-lg transition font-medium"><?php echo e(__('teacher.go_to_accounts')); ?></a>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/teacher/eccd.blade.php ENDPATH**/ ?>