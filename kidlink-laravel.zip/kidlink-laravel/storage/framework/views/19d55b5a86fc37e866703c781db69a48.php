<?php
    $lifetimeMinutes = (int) round($lifetimeMinutes);
    $lifetimeLabel = $lifetimeMinutes >= 60
        ? __('errors.lifetime_hours', ['n' => (int) round($lifetimeMinutes / 60)])
        : __('errors.lifetime_minutes', ['n' => $lifetimeMinutes]);
?>

<?php if (isset($component)) { $__componentOriginalae5c3ca666306b3b2dcb109e55417bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-layout','data' => ['title' => __('errors.session_timeout_title'),'tag' => __('errors.session_timeout_tag'),'heading' => __('errors.session_expired_h1'),'homeClass' => 'btn-quiet','footnote' => __('errors.signin_returns')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('error-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('errors.session_timeout_title')),'tag' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('errors.session_timeout_tag')),'heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('errors.session_expired_h1')),'home-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('btn-quiet'),'footnote' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('errors.signin_returns'))]); ?>
    <p>
        <?php echo e(__('errors.signout_intro', ['lifetime' => $lifetimeLabel])); ?>

        <?php echo e(__('errors.token_mismatch')); ?>

    </p>

    <p class="muted">
        <?php echo e(__('errors.nothing_saved')); ?>

        <?php if($attempted): ?>
            <br><?php echo e(__('errors.page_working_on')); ?>

            <code><?php echo e($attempted); ?></code>.
        <?php endif; ?>
    </p>

    <?php $__env->slot('actions'); ?>
        <a class="btn btn-primary" href="<?php echo e($loginUrl); ?>"><?php echo e(__('errors.sign_in_again')); ?></a>
        <a class="btn btn-quiet" href="<?php echo e($attempted ?: url('/')); ?>"><?php echo e(__('errors.reload_page')); ?></a>
    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9)): ?>
<?php $attributes = $__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9; ?>
<?php unset($__attributesOriginalae5c3ca666306b3b2dcb109e55417bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae5c3ca666306b3b2dcb109e55417bc9)): ?>
<?php $component = $__componentOriginalae5c3ca666306b3b2dcb109e55417bc9; ?>
<?php unset($__componentOriginalae5c3ca666306b3b2dcb109e55417bc9); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/errors/session-expired.blade.php ENDPATH**/ ?>