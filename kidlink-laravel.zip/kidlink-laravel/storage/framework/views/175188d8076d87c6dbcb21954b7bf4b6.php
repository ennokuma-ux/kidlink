<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>KidLink - <?php echo $__env->yieldContent('title', __('misc.daycare_management')); ?></title>
    
    
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/mascot.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/tailwind.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chart.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/alpine.min.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/mascot.js')); ?>"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-[#faf8f3] antialiased">
    <?php echo $__env->yieldContent('content'); ?>

    <?php if (isset($component)) { $__componentOriginal19737a51bfae7124ebbf6cd99387b232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19737a51bfae7124ebbf6cd99387b232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.session-keep-alive','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('session-keep-alive'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19737a51bfae7124ebbf6cd99387b232)): ?>
<?php $attributes = $__attributesOriginal19737a51bfae7124ebbf6cd99387b232; ?>
<?php unset($__attributesOriginal19737a51bfae7124ebbf6cd99387b232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19737a51bfae7124ebbf6cd99387b232)): ?>
<?php $component = $__componentOriginal19737a51bfae7124ebbf6cd99387b232; ?>
<?php unset($__componentOriginal19737a51bfae7124ebbf6cd99387b232); ?>
<?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php if(session('success')): ?>
    <script>
        Swal.fire({ icon: 'success', title: <?php echo json_encode(__('misc.success_title'), 15, 512) ?>, text: <?php echo json_encode(session('success'), 15, 512) ?>, timer: 3000, showConfirmButton: false });
    </script>
    <?php endif; ?>
    <?php if(session('info')): ?>
    <script>
        Swal.fire({ icon: 'info', title: <?php echo json_encode(__('misc.notice_title'), 15, 512) ?>, text: <?php echo json_encode(session('info'), 15, 512) ?>, timer: 3000, showConfirmButton: false });
    </script>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <script>
        Swal.fire({ icon: 'error', title: <?php echo json_encode(__('misc.error_title'), 15, 512) ?>, text: <?php echo json_encode($errors->first(), 15, 512) ?>, timer: 5000, showConfirmButton: false });
    </script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>