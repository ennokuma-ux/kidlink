<?php $__env->startSection('title', __('teacher.participation_title')); ?>
<?php $__env->startSection('page-title', __('teacher.participation_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <a href="<?php echo e(route('teacher.activities.index', ['week' => $activity->week_start ? \Illuminate\Support\Carbon::parse($activity->week_start)->startOfWeek(\Illuminate\Support\Carbon::MONDAY)->toDateString() : null])); ?>"
       class="text-sm text-[#ff8555] hover:text-[#f47548] font-medium">&larr; <?php echo e(__('teacher.back_to_planner')); ?></a>
</div>

<div class="bg-white rounded-xl shadow-sm p-5 mb-6">
    <div class="flex flex-wrap items-start justify-between gap-3">
        <div>
            <h2 class="text-lg font-bold text-[#182438]"><?php echo e($activity->title); ?></h2>
            <p class="text-sm text-[#5f6873] mt-1">
                <?php echo e($activity->type); ?> &middot; <?php echo e($activity->day_of_week); ?>

                <?php echo e(substr($activity->start_time, 0, 5)); ?> - <?php echo e(substr($activity->end_time, 0, 5)); ?>

                <?php if($activity->group_name): ?> &middot; <?php echo e($activity->group_name); ?> <?php endif; ?>
            </p>
        </div>
        <div class="flex gap-4 text-center">
            <div>
                <p class="text-xl font-bold text-[#182438]"><?php echo e($stats['participating']); ?></p>
                <p class="text-xs text-[#5f6873]"><?php echo e(__('teacher.participating')); ?></p>
            </div>
            <div>
                <p class="text-xl font-bold text-[#258cc5]"><?php echo e($stats['scored']); ?></p>
                <p class="text-xs text-[#5f6873]"><?php echo e(__('teacher.scored')); ?></p>
            </div>
            <div>
                <p class="text-xl font-bold text-[#68b82f]"><?php echo e($stats['average'] !== null ? $stats['average'] : '--'); ?></p>
                <p class="text-xs text-[#5f6873]"><?php echo e(__('teacher.average')); ?></p>
            </div>
        </div>
    </div>
</div>

<?php if($students->isEmpty()): ?>
    <div class="bg-white rounded-xl shadow-sm p-8 text-center">
        <p class="text-[#5f6873]"><?php echo e(__('teacher.no_students_to_record')); ?></p>
    </div>
<?php else: ?>
    <?php if($errors->any()): ?>
        <div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
            <ul class="list-disc pl-4 space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('teacher.activities.participation.save', $activity)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="bg-white rounded-xl shadow-sm overflow-hidden">
            <table class="w-full text-sm">
                <thead class="bg-[#faf8f3] text-left">
                    <tr>
                        <th class="px-4 py-3 font-semibold text-[#182438]"><?php echo e(__('teacher.took_part')); ?></th>
                        <th class="px-4 py-3 font-semibold text-[#182438]"><?php echo e(__('teacher.student')); ?></th>
                        <th class="px-4 py-3 font-semibold text-[#182438] w-28"><?php echo e(__('teacher.score')); ?></th>
                        <th class="px-4 py-3 font-semibold text-[#182438]"><?php echo e(__('teacher.feedback')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($record = $records->get($student->id)); ?>
                        <tr class="border-t border-[#ebe8e1] align-top">
                            <td class="px-4 py-3">
                                <input type="checkbox" name="participating[]" value="<?php echo e($student->id); ?>"
                                       class="participation-toggle w-5 h-5 rounded border-[#ebe8e1] text-[#ff8555] focus:ring-[#ff8555]"
                                       <?php if($record): echo 'checked'; endif; ?>>
                            </td>
                            <td class="px-4 py-3">
                                <span class="font-medium text-[#182438]"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></span>
                                <?php if($student->class_name): ?>
                                    <span class="block text-xs text-[#8b949d]"><?php echo e($student->class_name); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <input type="number" name="score[<?php echo e($student->id); ?>]" min="0" max="100"
                                       value="<?php echo e(old('score.'.$student->id, $record?->score)); ?>"
                                       data-score class="participation-field w-20 px-2 py-1.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none disabled:bg-[#f5f4f1] disabled:text-[#b8b4ab]">
                            </td>
                            <td class="px-4 py-3">
                                <input type="text" name="feedback[<?php echo e($student->id); ?>]" maxlength="1000"
                                       value="<?php echo e(old('feedback.'.$student->id, $record?->feedback)); ?>"
                                       data-feedback placeholder="<?php echo e(__('teacher.optional_note')); ?>"
                                       class="participation-field w-full px-2 py-1.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none disabled:bg-[#f5f4f1] disabled:text-[#b8b4ab]">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4 flex items-center justify-between">
            <p class="text-xs text-[#8b949d]"><?php echo e(__('teacher.unchecking_removes_record')); ?></p>
            <button type="submit" class="px-6 py-2.5 bg-[#ff8555] text-white rounded-lg hover:bg-[#f47548] transition font-medium"><?php echo e(__('teacher.save_participation')); ?></button>
        </div>
    </form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// A student who did not take part cannot carry a score or a note, so grey the
// two inputs out rather than accepting values that would be discarded on save.
function syncParticipationFields() {
    document.querySelectorAll('input[name="participating[]"]').forEach(toggle => {
        const row = toggle.closest('tr');
        row.querySelectorAll('[data-score], [data-feedback]').forEach(field => {
            field.disabled = !toggle.checked;
        });
    });
}

document.querySelectorAll('input[name="participating[]"]').forEach(toggle => {
    toggle.addEventListener('change', syncParticipationFields);
});

syncParticipationFields();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/teacher/activity-participation.blade.php ENDPATH**/ ?>