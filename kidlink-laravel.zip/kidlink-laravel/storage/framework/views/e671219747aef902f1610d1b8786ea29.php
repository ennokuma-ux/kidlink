﻿

<?php $__env->startSection('title', __('parent_ui.results_title')); ?>
<?php $__env->startSection('page-title', __('parent_ui.results_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(!$child): ?>
<div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg mb-6">
    <p class="text-yellow-700"><?php echo e(__('parent_ui.no_child_selected')); ?></p>
</div>
<?php else: ?>
<?php echo $__env->make('components.child_selector', ['children' => $children, 'child' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="mb-6">
    <h2 class="text-xl font-bold text-gray-800"><?php echo e(__('parent_ui.child_results', ['name' => $child->first_name])); ?></h2>
</div>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-blue-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_average_score')); ?></p>
        <p class="text-2xl font-bold text-gray-800 mt-1"><?php echo e(round($avgScore)); ?>%</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-green-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_excellent')); ?></p>
        <p class="text-2xl font-bold text-green-600 mt-1"><?php echo e($excellent); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-yellow-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_good')); ?></p>
        <p class="text-2xl font-bold text-yellow-600 mt-1"><?php echo e($good); ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-red-500">
        <p class="text-gray-400 text-xs font-semibold uppercase"><?php echo e(__('parent_ui.stat_needs_work')); ?></p>
        <p class="text-2xl font-bold text-red-500 mt-1"><?php echo e($needsWork); ?></p>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
    <h3 class="text-lg font-bold text-gray-800 mb-4"><?php echo e(__('parent_ui.score_history')); ?></h3>
    <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="flex items-center gap-4 p-4 <?php echo e($loop->last ? '' : 'border-b border-gray-50'); ?>">
        <div class="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm text-white" style="background: <?php echo e(($item->score ?? 0) >= 80 ? '#22c55e' : (($item->score ?? 0) >= 60 ? '#3b82f6' : '#ef4444')); ?>;">
            <?php echo e(round($item->score ?? 0)); ?>

        </div>
        <div class="flex-1">
            <p class="text-sm font-semibold text-gray-700"><?php echo e($item->activity->title ?? __('parent_ui.activity_fallback')); ?></p>
            <p class="text-xs text-gray-400"><?php echo e($item->created_at->diffForHumans()); ?></p>
        </div>
        <span class="px-3 py-1 rounded-full text-xs font-bold" style="background: <?php echo e(($item->score ?? 0) >= 80 ? '#dcfce7' : (($item->score ?? 0) >= 60 ? '#dbeafe' : '#fee2e2' )); ?>; color: <?php echo e(($item->score ?? 0) >= 80 ? '#16a34a' : (($item->score ?? 0) >= 60 ? '#2563eb' : '#dc2626')); ?>;">
            <?php echo e(($item->score ?? 0) >= 80 ? __('parent_ui.label_excellent') : (($item->score ?? 0) >= 60 ? __('parent_ui.label_good') : __('parent_ui.label_needs_work'))); ?>

        </span>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-gray-400 text-center py-8"><?php echo e(__('parent_ui.no_scored_activities')); ?></p>
    <?php endif; ?>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kidlink-laravel\resources\views/parent/results.blade.php ENDPATH**/ ?>