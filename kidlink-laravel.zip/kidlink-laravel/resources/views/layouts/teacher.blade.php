<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>KidLink - @yield('title', __('page.teacher_dashboard'))</title>
    
    
    <link href="{{ asset('css/fonts.css') }}" rel="stylesheet">
    <script src="{{ asset('js/tailwind.min.js') }}"></script>
    <script src="{{ asset('js/chart.umd.min.js') }}"></script>
    <script src="{{ asset('js/sweetalert2.min.js') }}"></script>
    <script defer src="{{ asset('js/alpine.min.js') }}"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
    @stack('styles')
</head>
<body class="bg-[#faf8f3] font-sans antialiased">
    <div class="flex h-screen bg-[#faf8f3]">
        @include('components.teacher_sidebar')
        <div class="flex-1 flex flex-col overflow-hidden md:ml-64">
            <header class="bg-white shadow-sm border-b border-[#ebe8e1] px-6 py-4">
                <div class="flex items-center justify-between">
                    <h1 class="text-2xl font-bold text-[#182438]">@yield('page-title', __('page.dashboard'))</h1>
                    <div class="flex items-center gap-4">
                        <x-lang_switcher />
                        <span class="text-sm text-[#5f6873]">{{ __('header.welcome', ['name' => auth()->user()->full_name]) }}</span>
                        @include('components.child_mode')
                        <form method="POST" action="{{ route('logout') }}" class="inline">
                            @csrf
                            <button type="submit" class="bg-[#f05d56] hover:bg-[#e04942] text-white px-4 py-2 rounded-lg text-sm transition">{{ __('header.logout') }}</button>
                        </form>
                    </div>
                </div>
            </header>
            <main class="flex-1 overflow-y-auto p-6">
                @yield('content')
            </main>
        </div>
    </div>
    <x-session-keep-alive />

    @stack('scripts')
    @if(session('success'))
    <script>Swal.fire({ icon: 'success', title: @json(__('misc.success_title')), text: @json(session('success')), timer: 3000, showConfirmButton: false });</script>
    @endif
    @if(session('error'))
    <script>Swal.fire({ icon: 'error', title: @json(__('misc.oops_title')), text: @json(session('error')) });</script>
    @endif
</body>
</html>
