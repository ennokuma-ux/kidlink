﻿@extends('layouts.teacher')

@section('title', __('teacher.activities_title'))
@section('page-title', __('teacher.activities_title'))

@section('content')
<div class="flex flex-wrap items-center justify-between gap-3 mb-6">
    <div class="flex items-center gap-2">
        <a href="{{ route('teacher.activities.index', ['week' => $prevWeek]) }}"
           class="px-3 py-2 border border-[#ebe8e1] rounded-lg text-[#182438] hover:bg-[#faf8f3] transition text-sm">&larr; {{ __('teacher.prev') }}</a>

        <div class="px-4 py-2 bg-white rounded-lg border border-[#ebe8e1] shadow-sm text-center">
            <span class="font-semibold text-[#182438]">{{ $weekStart->format('M j') }} &ndash; {{ $weekEnd->format('M j, Y') }}</span>
            @unless ($isCurrentWeek)
                <span class="ml-2 px-2 py-0.5 rounded text-xs font-medium bg-[#d9b348] text-white">{{ __('teacher.planning_ahead') }}</span>
            @endunless
        </div>

        <a href="{{ route('teacher.activities.index', ['week' => $nextWeek]) }}"
           class="px-3 py-2 border border-[#ebe8e1] rounded-lg text-[#182438] hover:bg-[#faf8f3] transition text-sm">{{ __('teacher.next') }} &rarr;</a>

        @unless ($isCurrentWeek)
            <a href="{{ route('teacher.activities.index') }}"
               class="px-3 py-2 text-sm text-[#ff8555] hover:text-[#f47548] font-medium">{{ __('teacher.this_week') }}</a>
        @endunless
    </div>

    <div class="flex gap-3">
        <button onclick="document.getElementById('addActivityModal').classList.remove('hidden')" class="bg-[#ff8555] text-white px-6 py-2.5 rounded-lg hover:bg-[#f47548] transition font-medium">
            {{ __('teacher.add_activity_plus') }}
        </button>
        <select id="typeFilter" onchange="filterActivities()" class="px-4 py-2.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            <option value="all">{{ __('teacher.all_types') }}</option>
            <option value="Lesson">{{ __('teacher.type_lesson') }}</option>
            <option value="Craft">{{ __('teacher.type_craft') }}</option>
            <option value="Music">{{ __('teacher.type_music') }}</option>
            <option value="Story">{{ __('teacher.type_story') }}</option>
            <option value="Movement">{{ __('teacher.type_movement') }}</option>
        </select>
    </div>
</div>

<div class="grid grid-cols-3 gap-6 mb-6">
    <div class="bg-white rounded-xl shadow-sm p-4 text-center border-l-4 border-[#ff8555]">
        <p class="text-2xl font-bold text-[#182438]">{{ $stats['total'] }}</p>
        <p class="text-sm text-[#5f6873]">{{ __('teacher.activities_this_week') }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-4 text-center border-l-4 border-[#68b82f]">
        <p class="text-2xl font-bold text-[#68b82f]">{{ $stats['completed'] }}</p>
        <p class="text-sm text-[#5f6873]">{{ __('teacher.completed') }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-4 text-center border-l-4 border-[#d9b348]">
        <p class="text-2xl font-bold text-[#d9b348]">{{ $stats['pending'] }}</p>
        <p class="text-sm text-[#5f6873]">{{ __('teacher.pending') }}</p>
    </div>
</div>

@if ($stats['total'] === 0)
    <div class="bg-white rounded-xl shadow-sm p-8 mb-6 text-center">
        <p class="text-[#5f6873]">{{ __('teacher.no_activities_this_week') }}</p>
        <p class="text-sm text-[#8b949d] mt-1">{{ __('teacher.use_add_activity') }}</p>
    </div>
@endif

<div class="grid grid-cols-5 gap-4">
    @foreach($days as $offset => $day)
        @php($date = $weekStart->copy()->addDays($offset))
        <div class="bg-white rounded-xl shadow-sm overflow-hidden {{ $date->isToday() ? 'ring-2 ring-[#ff8555]' : '' }}">
            <div class="text-center py-3 font-semibold {{ $date->isToday() ? 'bg-[#ff8555] text-white' : 'bg-[#ebe8e1] text-[#182438]' }}">
                {{ $date->format('D') }}
                <span class="block text-xs font-normal opacity-80">{{ $date->format('M j') }}</span>
            </div>
            <div class="p-3 space-y-2 min-h-[200px]">
                @forelse(($activities[$day] ?? collect()) as $activity)
                <div class="p-3 rounded-lg border text-sm activity-card {{ $activity->is_completed ? 'opacity-60' : '' }}"
                     data-type="{{ $activity->type }}"
                     data-id="{{ $activity->id }}"
                     data-title="{{ $activity->title }}"
                     data-day="{{ $activity->day_of_week }}"
                     data-start="{{ substr($activity->start_time, 0, 5) }}"
                     data-end="{{ substr($activity->end_time, 0, 5) }}"
                     data-group="{{ $activity->group_name }}"
                     data-update-url="{{ route('teacher.activities.update', $activity) }}">
                    <div class="flex items-center justify-between mb-1">
                        <span class="font-semibold text-[#182438]">{{ $activity->title }}</span>
                        <span class="px-2 py-0.5 rounded text-xs font-medium
                            {{ $activity->type === 'Lesson' ? 'bg-blue-100 text-blue-700' : '' }}
                            {{ $activity->type === 'Craft' ? 'bg-orange-100 text-orange-700' : '' }}
                            {{ $activity->type === 'Music' ? 'bg-pink-100 text-pink-700' : '' }}
                            {{ $activity->type === 'Story' ? 'bg-green-100 text-green-700' : '' }}
                            {{ $activity->type === 'Movement' ? 'bg-yellow-100 text-yellow-700' : '' }}">
                            {{ $activity->type }}
                        </span>
                    </div>
                    <p class="text-[#5f6873] text-xs">{{ substr($activity->start_time, 0, 5) }} - {{ substr($activity->end_time, 0, 5) }}</p>
                    @if($activity->group_name)<p class="text-[#8b949d] text-xs mt-1">{{ __('teacher.group_label') }} {{ $activity->group_name }}</p>@endif
                    <div class="flex items-center justify-between mt-2 pt-2 border-t">
                        <form method="POST" action="{{ route('teacher.activities.toggle', $activity) }}" class="inline">
                            @csrf @method('PUT')
                            <button type="submit" class="text-xs {{ $activity->is_completed ? 'text-[#68b82f]' : 'text-[#8b949d]' }}">
                                {{ $activity->is_completed ? __('teacher.completed') : __('teacher.mark_done') }}
                            </button>
                        </form>
                        <div class="flex items-center gap-3">
                            <a href="{{ route('teacher.activities.participation', $activity) }}" class="text-xs text-[#258cc5] hover:underline">{{ __('teacher.record') }}</a>
                            <button type="button" onclick="openEditModal(this)" class="text-xs text-[#8b949d] hover:text-[#182438]">{{ __('teacher.edit') }}</button>
                            <form method="POST" action="{{ route('teacher.activities.destroy', $activity) }}" class="inline" onsubmit="return confirm('{{ __('teacher.delete_confirm') }}')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-xs text-red-500">{{ __('teacher.delete') }}</button>
                            </form>
                        </div>
                    </div>
                </div>
                @empty
                <p class="text-[#8b949d] text-xs text-center py-4">{{ __('teacher.no_activities') }}</p>
                @endforelse
            </div>
        </div>
    @endforeach
</div>

<div id="addActivityModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-2xl p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-[#182438]">{{ __('teacher.new_activity') }}</h3>
            <button onclick="this.closest('#addActivityModal').classList.add('hidden')" class="text-[#8b949d] hover:text-[#5f6873] text-2xl">&times;</button>
        </div>

        @if ($errors->any())
            <div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
                <ul class="list-disc pl-4 space-y-1">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('teacher.activities.store') }}" class="space-y-4">
            @csrf
            <input type="hidden" name="week" value="{{ $weekStart->toDateString() }}">
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.title') }}</label>
                <input type="text" name="title" required maxlength="255" value="{{ old('title') }}" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.type') }}</label>
                <select name="type" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    <option value="Lesson">{{ __('teacher.type_lesson') }}</option>
                    <option value="Craft">{{ __('teacher.type_craft') }}</option>
                    <option value="Music">{{ __('teacher.type_music') }}</option>
                    <option value="Story">{{ __('teacher.type_story') }}</option>
                    <option value="Movement">{{ __('teacher.type_movement') }}</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.day') }}</label>
                <select name="day_of_week" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    @foreach($days as $offset => $day)
                        <option value="{{ $day }}">{{ $weekStart->copy()->addDays($offset)->format('D') }}, {{ $weekStart->copy()->addDays($offset)->format('M j') }}</option>
                    @endforeach
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.start_time') }}</label>
                    <input type="time" name="start_time" required value="{{ old('start_time') }}" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.end_time') }}</label>
                    <input type="time" name="end_time" required value="{{ old('end_time') }}" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.group_optional') }}</label>
                <input type="text" name="group_name" maxlength="255" value="{{ old('group_name') }}" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <p class="text-xs text-[#8b949d]">
                {{ __('teacher.scheduled_for_week', ['date' => $weekStart->format('M j, Y')]) }}
            </p>
            <div class="flex justify-end gap-3 pt-4">
                <button type="button" onclick="this.closest('#addActivityModal').classList.add('hidden')" class="px-6 py-2.5 border border-[#ebe8e1] rounded-lg text-[#182438] hover:bg-[#faf8f3] transition">{{ __('teacher.cancel') }}</button>
                <button type="submit" class="px-6 py-2.5 bg-[#ff8555] text-white rounded-lg hover:bg-[#f47548] transition font-medium">{{ __('teacher.add_activity') }}</button>
            </div>
        </form>
    </div>
</div>
<div id="editActivityModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-2xl p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-[#182438]">{{ __('teacher.edit_activity') }}</h3>
            <button onclick="this.closest('#editActivityModal').classList.add('hidden')" class="text-[#8b949d] hover:text-[#5f6873] text-2xl">&times;</button>
        </div>

        @if ($errors->any())
            <div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
                <ul class="list-disc pl-4 space-y-1">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" id="editActivityForm" class="space-y-4">
            @csrf @method('PUT')
            <input type="hidden" name="_activity_id" id="editActivityId">
            <input type="hidden" name="week" id="editWeek" value="{{ $weekStart->toDateString() }}">
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.title') }}</label>
                <input type="text" name="title" id="editTitle" required maxlength="255" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.type') }}</label>
                <select name="type" id="editType" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    <option value="Lesson">{{ __('teacher.type_lesson') }}</option>
                    <option value="Craft">{{ __('teacher.type_craft') }}</option>
                    <option value="Music">{{ __('teacher.type_music') }}</option>
                    <option value="Story">{{ __('teacher.type_story') }}</option>
                    <option value="Movement">{{ __('teacher.type_movement') }}</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.day') }}</label>
                <select name="day_of_week" id="editDay" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                    @foreach($days as $day)
                        <option value="{{ $day }}">{{ $day }}</option>
                    @endforeach
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.start_time') }}</label>
                    <input type="time" name="start_time" id="editStart" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
                <div>
                    <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.end_time') }}</label>
                    <input type="time" name="end_time" id="editEnd" required class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-[#182438] mb-2">{{ __('teacher.group_optional') }}</label>
                <input type="text" name="group_name" id="editGroup" maxlength="255" class="w-full px-4 py-3 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
            <div class="flex justify-end gap-3 pt-4">
                <button type="button" onclick="this.closest('#editActivityModal').classList.add('hidden')" class="px-6 py-2.5 border border-[#ebe8e1] rounded-lg text-[#182438] hover:bg-[#faf8f3] transition">{{ __('teacher.cancel') }}</button>
                <button type="submit" class="px-6 py-2.5 bg-[#ff8555] text-white rounded-lg hover:bg-[#f47548] transition font-medium">{{ __('teacher.save_changes') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function filterActivities() {
    const type = document.getElementById('typeFilter').value;
    document.querySelectorAll('.activity-card').forEach(card => {
        card.style.display = (type === 'all' || card.dataset.type === type) ? '' : 'none';
    });
}

function openEditModal(button) {
    const card = button.closest('.activity-card');
    document.getElementById('editActivityForm').action = card.dataset.updateUrl;
    document.getElementById('editActivityId').value = card.dataset.id;
    document.getElementById('editTitle').value = card.dataset.title || '';
    document.getElementById('editType').value = card.dataset.type || 'Lesson';
    document.getElementById('editDay').value = card.dataset.day || 'Monday';
    document.getElementById('editStart').value = card.dataset.start || '';
    document.getElementById('editEnd').value = card.dataset.end || '';
    document.getElementById('editGroup').value = card.dataset.group || '';
    document.getElementById('editActivityModal').classList.remove('hidden');
}

@if ($errors->any())
    @if (old('_activity_id'))
        // The edit form bounced: restore it instead of the create form.
        document.getElementById('editActivityForm').action = @json(route('teacher.activities.update', old('_activity_id')));
        document.getElementById('editActivityId').value = @json(old('_activity_id'));
        document.getElementById('editTitle').value = @json(old('title'));
        document.getElementById('editType').value = @json(old('type'));
        document.getElementById('editDay').value = @json(old('day_of_week'));
        document.getElementById('editStart').value = @json(old('start_time'));
        document.getElementById('editEnd').value = @json(old('end_time'));
        document.getElementById('editGroup').value = @json(old('group_name'));
        document.getElementById('editWeek').value = @json(old('week'));
        document.getElementById('editActivityModal').classList.remove('hidden');
    @else
        document.getElementById('addActivityModal').classList.remove('hidden');
    @endif
@endif
</script>
@endpush
