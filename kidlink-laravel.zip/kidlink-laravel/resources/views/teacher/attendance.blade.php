﻿@extends('layouts.teacher')

@section('title', __('teacher.attendance_title'))
@section('page-title', __('teacher.daily_attendance_title'))

@section('content')
<div class="bg-white rounded-xl shadow-sm p-6 mb-6">
    <form method="GET" action="{{ route('teacher.attendance.index') }}"
        class="flex flex-col lg:flex-row lg:items-end gap-4">
        <div>
            <label class="block text-[#182438] font-medium mb-2">{{ __('teacher.select_date') }}</label>
            <input type="date" name="date" value="{{ $date->format('Y-m-d') }}" onchange="this.form.submit()"
                class="w-full px-4 py-2.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
        </div>
        <div class="flex-1 min-w-0">
            <label for="attendanceSearch" class="block text-[#182438] font-medium mb-2">{{ __('teacher.search_student') }}</label>
            <div class="relative">
                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-[#8b949d]">&nbsp;&#9906;</span>
                <input type="search" name="search" id="attendanceSearch" value="{{ $search }}"
                    placeholder="{{ __('teacher.type_a_name') }}" autocomplete="off"
                    class="w-full pl-9 pr-4 py-2.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
            </div>
        </div>
        <div class="w-full lg:w-56">
            <label for="attendanceSection" class="block text-[#182438] font-medium mb-2">{{ __('teacher.section') }}</label>
            <select name="section" id="attendanceSection" onchange="this.form.submit()"
                class="w-full px-4 py-2.5 border border-[#ebe8e1] rounded-lg focus:ring-2 focus:ring-[#ff8555] outline-none">
                <option value="">{{ __('teacher.all_sections') }}</option>
                @foreach($availableSections as $available)
                    <option value="{{ $available }}" {{ $section === $available ? 'selected' : '' }}>{{ $available }}</option>
                @endforeach
            </select>
        </div>
        <div class="flex gap-3">
            <button type="submit" class="bg-[#ff8555] text-white px-6 py-2.5 rounded-lg hover:bg-[#f47548] transition font-medium">{{ __('teacher.apply') }}</button>
            @if($search !== '' || $section !== '')
                <a href="{{ route('teacher.attendance.index', ['date' => $date->format('Y-m-d')]) }}"
                    class="px-6 py-2.5 border border-[#ebe8e1] rounded-lg text-[#5f6873] hover:bg-[#faf8f3] transition">{{ __('teacher.clear') }}</a>
            @endif
        </div>
    </form>

    @if($search !== '' || $section !== '')
        <p class="text-sm text-[#5f6873] mt-4 pt-4 border-t border-[#ebe8e1]">
            {{ __('teacher.showing') }} <span class="font-semibold text-[#182438]">{{ $students->count() }}</span>
            {{ __('teacher.of') }} {{ $totalStudents }}
            {{ $totalStudents === 1 ? __('teacher.student_singular') : __('teacher.student_plural') }}@if($section) {{ __('teacher.in_section') }} <span class="font-semibold text-[#182438]">{{ $section }}</span>@endif
            @if($search) {{ __('teacher.matching_query') }} &ldquo;<span class="font-semibold text-[#182438]">{{ $search }}</span>&rdquo;@endif.
            {{ __('teacher.only_shown_saved') }}
        </p>
    @endif
</div>

<div class="grid grid-cols-4 gap-6 mb-6">
    <div class="bg-white rounded-xl shadow-sm p-4 text-center border-l-4 border-[#258cc5]">
<p class="text-2xl font-bold text-[#182438]">{{ $stats['total'] }}</p>
        <p class="text-sm text-[#5f6873]">{{ ($search !== '' || $section !== '') ? __('teacher.matching_students') : __('teacher.total_students') }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-4 text-center border-l-4 border-[#68b82f]">
        <p class="text-2xl font-bold text-[#68b82f]">{{ $stats['present'] }}</p>
        <p class="text-sm text-[#5f6873]">{{ __('teacher.present') }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-4 text-center border-l-4 border-[#f05d56]">
        <p class="text-2xl font-bold text-[#f05d56]">{{ $stats['absent'] }}</p>
        <p class="text-sm text-[#5f6873]">{{ __('teacher.absent') }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-4 text-center border-l-4 border-[#d9b348]">
        <p class="text-2xl font-bold text-[#d9b348]">{{ $stats['late'] }}</p>
        <p class="text-sm text-[#5f6873]">{{ __('teacher.late') }}</p>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm overflow-hidden">
    <form method="POST" action="{{ route('teacher.attendance.store') }}">
        @csrf
<input type="hidden" name="date" value="{{ $date->format('Y-m-d') }}">
        <input type="hidden" name="search" value="{{ $search }}">
        <input type="hidden" name="section" value="{{ $section }}">
        <table class="w-full">
            <thead class="bg-[#faf8f3]">
                <tr>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-[#5f6873]">{{ __('teacher.student') }}</th>
                    @if($availableSections->count() > 1)
                        <th class="px-6 py-4 text-left text-sm font-semibold text-[#5f6873]">{{ __('teacher.section') }}</th>
                    @endif
                    <th class="px-6 py-4 text-center text-sm font-semibold text-[#5f6873]">{{ __('teacher.present') }}</th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-[#5f6873]">{{ __('teacher.absent') }}</th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-[#5f6873]">{{ __('teacher.late') }}</th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-[#5f6873]">{{ __('teacher.excused') }}</th>
                    <th class="px-6 py-4 text-center text-sm font-semibold text-[#5f6873]">{{ __('teacher.none') }}</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-[#ebe8e1]">
                @forelse($students as $student)
                @php $record = $attendance->get($student->id); @endphp
<tr class="hover:bg-[#faf8f3] transition">
                    <td class="px-6 py-4">
                        <div class="flex items-center gap-3">
                            <span class="font-medium text-[#182438]">{{ $student->name }}</span>
                        </div>
                    </td>
                    @if($availableSections->count() > 1)
                        <td class="px-6 py-4">
                            @if($student->class_name)
                                <span class="px-2.5 py-1 bg-[#f5f3ee] rounded-full text-xs font-medium text-[#5f6873]">{{ $student->class_name }}</span>
                            @else
                                <span class="text-xs text-[#8b949d]">&mdash;</span>
                            @endif
                        </td>
                    @endif
                    @foreach(['Present','Absent','Late','Excused','None'] as $status)
                    <td class="px-6 py-4 text-center">
                        <label class="inline-flex items-center">
                            <input type="radio" name="attendance[{{ $student->id }}]" value="{{ $status }}"
                                {{ ($record && $record->status === $status) ? 'checked' : (!$record && $status === 'Present' ? 'checked' : '') }}
                                class="w-5 h-5 text-[#ff8555] focus:ring-[#ff8555]">
                            <span class="ml-1 text-sm {{ $record && $record->status === $status ? 'font-semibold' : '' }}"></span>
                        </label>
                    </td>
                    @endforeach
                </tr>
@empty
                <tr>
                    <td colspan="{{ $availableSections->count() > 1 ? 7 : 6 }}" class="px-6 py-12 text-center text-[#8b949d]">
                        @if($search !== '' || $section !== '')
                            {{ __('teacher.no_students_match') }}
                        @else
                            {{ __('teacher.no_active_students') }}
                        @endif
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
        @if($students->count() > 0)
        <div class="p-6 border-t">
            <button type="submit" class="bg-[#ff8555] text-white px-8 py-3 rounded-lg hover:bg-[#f47548] transition font-medium">{{ __('teacher.save_attendance') }}</button>
        </div>
        @endif
    </form>
</div>
@endsection

@push('scripts')
<script>
document.querySelectorAll('input[type="radio"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const name = this.name;
        document.querySelectorAll(`input[name="${name}"]`).forEach(r => {
            const span = r.nextElementSibling;
            if (span) span.classList.remove('font-semibold');
        });
        if (this.checked) {
            const span = this.nextElementSibling;
            if (span) span.classList.add('font-semibold');
        }
    });
});
</script>
@endpush




