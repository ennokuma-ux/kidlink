@props([
    'interventions' => [],
    'heading' => null,
])

{{--
    A student who is missing attendance records, or who has no scores at all for
    a topic, looks identical to a student doing fine once the numbers are
    averaged. Nothing in a chart of averages can show an unrecorded register, so
    it gets stated outright, above the headline stats.

    Expects $interventions rows from AnalyticsService::interventionFlags():
      student_id, name, class_name, intervention_required, severity, gap_count, reasons[]
    Ordered most urgent first by the service. Every returned row needs action;
    $severity is what decides who gets picked up first.
--}}

<div class="rounded-xl border-2 mb-8
    {{ $interventions === [] ? 'bg-white border-[#b8e0c2]' : 'bg-[#fff5f7] border-[#f05d56]' }}">
    <div class="flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-b
        {{ $interventions === [] ? 'border-[#ebe8e1]' : 'border-[#f5c6cf]' }}">
        <div class="flex items-center gap-3">
            @if($interventions === [])
                <span class="w-9 h-9 rounded-full bg-[#e2f4e8] text-[#68b82f] flex items-center justify-center text-lg font-bold" aria-hidden="true">&check;</span>
            @else
                <span class="w-9 h-9 rounded-full bg-[#f05d56] text-white flex items-center justify-center font-bold" aria-hidden="true">!</span>
            @endif
            <div>
                <h3 class="text-lg font-semibold text-[#182438]">{{ $heading ?: __('intervention.heading') }}</h3>
                <p class="text-xs text-[#8b949d]">
                    {{ __('intervention.subtitle', ['days' => \App\Services\AnalyticsService::ATTENDANCE_WINDOW_DAYS]) }}
                    
                </p>
            </div>
        </div>
        @if($interventions !== [])
            <span class="px-3 py-1.5 rounded-full bg-[#f05d56] text-white text-xs font-bold uppercase tracking-wide">
                {{ trans_choice('intervention.count', count($interventions), ['count' => count($interventions)]) }}
                
            </span>
        @endif
    </div>

    @if($interventions === [])
        <div class="px-6 py-8 text-center">
            <p class="text-[#182438] font-semibold">{{ __('intervention.nothing_missing') }}</p>
            <p class="text-sm text-[#5f6873] mt-1">
                {{ __('intervention.all_clear') }}
            </p>
        </div>
    @else
        <div class="divide-y divide-[#ebe8e1]">
            @foreach ($interventions as $flag)
                <div class="px-6 py-4">
                    <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div class="flex items-center gap-2">
                            <h4 class="font-semibold text-[#182438]">{{ $flag['name'] }}</h4>
                            <span class="inline-flex items-center gap-1.5 text-xs text-[#5f6873]">
                                <span class="w-2 h-2 rounded-full"
                                      style="background-color: {{ \App\Models\Student::colorForSection($flag['class_name']) }}"></span>
                                {{ \App\Models\Student::sectionLabel($flag['class_name']) }}
                            </span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full
                                {{ $flag['severity'] === 'high' ? 'bg-[#f05d56] text-white' : ($flag['severity'] === 'medium' ? 'bg-[#d9b348] text-white' : 'bg-[#68b82f] text-white') }}">
                                {{ __('intervention.severity_' . $flag['severity']) }}
                            </span>
                            <span class="text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full bg-[#f05d56] text-white">
                                {{ __('intervention.required') }}
                            </span>
                        </div>
                    </div>

                    <ul class="space-y-2 mt-2">
                        @foreach ($flag['reasons'] as $reason)
                            <li class="flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-3">
                                <span class="shrink-0 text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full mt-0.5
                                    {{ $reason['type'] === 'Attendance' ? 'bg-[#fde8ef] text-[#f05d56]' : ($reason['type'] === 'Baseline' ? 'bg-[#fff6e5] text-[#a16207]' : 'bg-[#eef3f9] text-[#258cc5]') }}">
                                    {{ __('intervention.type_' . strtolower($reason['type'])) }}
                                </span>
                                <span class="text-sm text-[#5f6873]">
                                    <span class="font-medium text-[#182438]">{{ $reason['label'] }}.</span>
                                    {{ $reason['message'] }}
                                    <span class="block text-xs text-[#8b949d] mt-0.5">{{ __('intervention.do') }} {{ $reason['action'] }}</span>
                                </span>
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endforeach
        </div>
    @endif
</div>