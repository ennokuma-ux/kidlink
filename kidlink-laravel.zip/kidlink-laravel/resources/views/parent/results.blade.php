﻿@extends('layouts.parent')

@section('title', __('parent_ui.results_title'))
@section('page-title', __('parent_ui.results_title'))

@section('content')
@if(!$child)
<div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg mb-6">
    <p class="text-yellow-700">{{ __('parent_ui.no_child_selected') }}</p>
</div>
@else
@include('components.child_selector', ['children' => $children, 'child' => $child])

<div class="mb-6">
    <h2 class="text-xl font-bold text-gray-800">{{ __('parent_ui.child_results', ['name' => $child->first_name]) }}</h2>
</div>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-blue-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_average_score') }}</p>
        <p class="text-2xl font-bold text-gray-800 mt-1">{{ round($avgScore) }}%</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-green-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_excellent') }}</p>
        <p class="text-2xl font-bold text-green-600 mt-1">{{ $excellent }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-yellow-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_good') }}</p>
        <p class="text-2xl font-bold text-yellow-600 mt-1">{{ $good }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-red-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_needs_work') }}</p>
        <p class="text-2xl font-bold text-red-500 mt-1">{{ $needsWork }}</p>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
    <h3 class="text-lg font-bold text-gray-800 mb-4">{{ __('parent_ui.score_history') }}</h3>
    @forelse($results as $item)
    <div class="flex items-center gap-4 p-4 {{ $loop->last ? '' : 'border-b border-gray-50' }}">
        <div class="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm text-white" style="background: {{ ($item->score ?? 0) >= 80 ? '#22c55e' : (($item->score ?? 0) >= 60 ? '#3b82f6' : '#ef4444') }};">
            {{ round($item->score ?? 0) }}
        </div>
        <div class="flex-1">
            <p class="text-sm font-semibold text-gray-700">{{ $item->activity->title ?? __('parent_ui.activity_fallback') }}</p>
            <p class="text-xs text-gray-400">{{ $item->created_at->diffForHumans() }}</p>
        </div>
        <span class="px-3 py-1 rounded-full text-xs font-bold" style="background: {{ ($item->score ?? 0) >= 80 ? '#dcfce7' : (($item->score ?? 0) >= 60 ? '#dbeafe' : '#fee2e2' ) }}; color: {{ ($item->score ?? 0) >= 80 ? '#16a34a' : (($item->score ?? 0) >= 60 ? '#2563eb' : '#dc2626') }};">
            {{ ($item->score ?? 0) >= 80 ? __('parent_ui.label_excellent') : (($item->score ?? 0) >= 60 ? __('parent_ui.label_good') : __('parent_ui.label_needs_work')) }}
        </span>
    </div>
    @empty
    <p class="text-gray-400 text-center py-8">{{ __('parent_ui.no_scored_activities') }}</p>
    @endforelse
</div>

@endif
@endsection
