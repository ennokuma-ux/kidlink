﻿@extends('layouts.parent')

@section('title', __('parent_ui.attendance_title'))
@section('page-title', __('parent_ui.attendance_title'))

@section('content')
@if(!$child)
<div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg mb-6">
    <p class="text-yellow-700">{{ __('parent_ui.no_child_selected') }}</p>
</div>
@else
@include('components.child_selector', ['children' => $children, 'child' => $child])

<div class="mb-6">
    <h2 class="text-xl font-bold text-gray-800">{{ __('parent_ui.child_attendance', ['name' => $child->first_name]) }}</h2>
    <p class="text-gray-500 text-sm">{{ $month->format('F Y') }}</p>
</div>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-green-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_present') }}</p>
        <p class="text-2xl font-bold text-green-600 mt-1">{{ $present }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-red-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_absent') }}</p>
        <p class="text-2xl font-bold text-red-500 mt-1">{{ $absent }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-yellow-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_late') }}</p>
        <p class="text-2xl font-bold text-yellow-500 mt-1">{{ $late }}</p>
    </div>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-blue-500">
        <p class="text-gray-400 text-xs font-semibold uppercase">{{ __('parent_ui.stat_rate') }}</p>
        <p class="text-2xl font-bold text-blue-500 mt-1">{{ $rate }}%</p>
    </div>
</div>

<!-- Month Navigation -->
<div class="flex items-center gap-3 mb-6">
    <a href="?month={{ $month->copy()->subMonth()->format('Y-m') }}" class="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm font-semibold hover:border-orange-300 transition">{{ __('parent_ui.prev_month') }}</a>
    <span class="text-sm font-bold text-gray-700">{{ $month->format('F Y') }}</span>
    <a href="?month={{ $month->copy()->addMonth()->format('Y-m') }}" class="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm font-semibold hover:border-orange-300 transition">{{ __('parent_ui.next_month') }}</a>
</div>

<!-- Calendar Grid -->
<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-8">
    <div class="grid grid-cols-7 gap-2">
        @foreach([__('parent_ui.day_sun'), __('parent_ui.day_mon'), __('parent_ui.day_tue'), __('parent_ui.day_wed'), __('parent_ui.day_thu'), __('parent_ui.day_fri'), __('parent_ui.day_sat')] as $day)
        <div class="text-center text-xs font-bold text-gray-400 pb-2">{{ $day }}</div>
        @endforeach
        @php
        $firstDay = $month->copy()->startOfMonth()->dayOfWeek;
        $daysInMonth = $month->daysInMonth;
        @endphp
        @for($i = 0; $i < $firstDay; $i++)
        <div></div>
        @endfor
        @foreach($monthlyChart as $day)
        @php
        $bg = match($day['status']) {
            'Present' => 'bg-green-100 text-green-700',
            'Absent' => 'bg-red-100 text-red-700',
            'Late' => 'bg-yellow-100 text-yellow-700',
            default => 'bg-gray-50 text-gray-400',
        };
        @endphp
        <div class="text-center p-2 rounded-lg text-sm font-semibold {{ $bg }}">
            {{ $day['day'] }}
        </div>
        @endforeach
    </div>
</div>

<!-- Monthly Summary -->
@if(count($monthlySummary) > 0)
<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
    <h3 class="text-lg font-bold text-gray-800 mb-4">{{ __('parent_ui.monthly_summary') }}</h3>
    @foreach($monthlySummary as $m)
    <div class="flex items-center gap-4 p-3 {{ $loop->last ? '' : 'border-b border-gray-50' }}">
        <div class="w-24">
            <p class="text-sm font-semibold text-gray-700">{{ $m['month'] }}</p>
        </div>
        <div class="flex-1">
            <div class="w-full bg-gray-100 rounded-full h-2">
                <div class="h-2 rounded-full bg-green-500" style="width: {{ $m['rate'] }}%"></div>
            </div>
        </div>
        <div class="text-right">
            <span class="text-sm font-bold text-gray-600">{{ $m['rate'] }}%</span>
        </div>
    </div>
    @endforeach
</div>
@endif

@endif
@endsection
