﻿@extends('layouts.parent')

@section('title', __('parent_ui.milestones_title'))
@section('page-title', __('parent_ui.milestones_title'))

@section('content')
@if(!$child)
<div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg mb-6">
    <p class="text-yellow-700">{{ __('parent_ui.no_child_selected') }}</p>
</div>
@else
@include('components.child_selector', ['children' => $children, 'child' => $child])

<div class="mb-6">
    <h2 class="text-xl font-bold text-gray-800">{{ __('parent_ui.child_milestones', ['name' => $child->first_name]) }}</h2>
    <p class="text-gray-500 text-sm">{{ __('parent_ui.overall_prefix') }} <span class="font-bold">{{ $overallPercentage }}%</span> {{ __('parent_ui.overall_suffix') }}</p>
</div>

<!-- Domain Stats -->
<div class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
    @foreach($domainStats as $domain => $stat)
    <div class="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
        <p class="text-sm font-bold text-gray-700 mb-2">{{ $domain }}</p>
        <div class="flex items-center gap-2 mb-2">
            <span class="text-2xl font-bold" style="color: {{ $stat['percentage'] >= 80 ? '#22c55e' : ($stat['percentage'] >= 50 ? '#3b82f6' : '#f97316') }};">{{ $stat['percentage'] }}%</span>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-2">
            <div class="h-2 rounded-full" style="width: {{ $stat['percentage'] }}%; background: {{ $stat['percentage'] >= 80 ? '#22c55e' : ($stat['percentage'] >= 50 ? '#3b82f6' : '#f97316') }};"></div>
        </div>
        <p class="text-xs text-gray-400 mt-1">{{ $stat['achieved'] }}/{{ $stat['total'] }} {{ __('parent_ui.achieved_label') }}</p>
    </div>
    @endforeach
</div>

<!-- Domain Filter -->
<div class="flex flex-wrap gap-2 mb-6">
    <a href="?domain=all" class="px-4 py-2 rounded-lg text-sm font-semibold transition {{ $domain === 'all' ? 'bg-orange-500 text-white' : 'bg-white text-gray-500 border border-gray-200 hover:border-orange-300' }}">{{ __('parent_ui.filter_all') }}</a>
    @foreach($domains as $d)
    <a href="?domain={{ urlencode($d) }}" class="px-4 py-2 rounded-lg text-sm font-semibold transition {{ $domain === $d ? 'bg-orange-500 text-white' : 'bg-white text-gray-500 border border-gray-200 hover:border-orange-300' }}">{{ $d }}</a>
    @endforeach
</div>

<!-- Records -->
<div class="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
    @forelse($records as $record)
    <div class="flex items-center gap-4 p-4 {{ $loop->last ? '' : 'border-b border-gray-50' }}">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold" style="background: {{ $record->status === 'Achieved' ? '#dcfce7' : ($record->status === 'In Progress' ? '#dbeafe' : '#fee2e2') }}; color: {{ $record->status === 'Achieved' ? '#16a34a' : ($record->status === 'In Progress' ? '#2563eb' : '#dc2626') }};">
            {{ $record->status === 'Achieved' ? '✓' : ($record->status === 'In Progress' ? '○' : '✗') }}
        </div>
        <div class="flex-1">
            <p class="text-sm font-semibold text-gray-700">{{ $record->indicator ?? $record->domain }}</p>
            <p class="text-xs text-gray-400">{{ $record->domain }}</p>
        </div>
        <span class="px-3 py-1 rounded-full text-xs font-bold" style="background: {{ $record->status === 'Achieved' ? '#dcfce7' : ($record->status === 'In Progress' ? '#dbeafe' : '#fee2e2') }}; color: {{ $record->status === 'Achieved' ? '#16a34a' : ($record->status === 'In Progress' ? '#2563eb' : '#dc2626') }};">
            {{ $record->status }}
        </span>
    </div>
    @empty
    <p class="text-gray-400 text-center py-8">{{ __('parent_ui.no_milestone_records') }}</p>
    @endforelse
</div>

@endif
@endsection
