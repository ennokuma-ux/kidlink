@extends('layouts.announcements')

@section('title', __('announcements.announcements'))
@section('page-title', __('announcements.announcements'))

@section('content')
@php
    $canPost = in_array(auth()->user()->role, ['super_admin', 'admin', 'teacher'], true);
@endphp

<div class="bg-white rounded-xl shadow-sm p-6 mb-6">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h2 class="text-xl font-bold text-[#182438]">{{ __('announcements.announcements') }}</h2>
            <p class="text-sm text-[#5f6873] mt-1">
                {{ $canPost
                    ? __('announcements.post_updates_description')
                    : __('announcements.updates_from_description') }}
            </p>
        </div>
        @if($canPost)
            <a href="{{ route('announcements.create') }}" class="bg-[#ff8555] hover:bg-[#f47548] text-white px-6 py-2.5 rounded-lg transition font-medium self-start md:self-auto">
                {{ __('announcements.new_announcement_button') }}
            </a>
        @endif
    </div>
</div>

@if(!$canPost)
    <div class="bg-[#fff8f2] border border-[#ffe0cc] rounded-xl p-4 mb-6 flex items-start gap-3">
        <svg class="w-5 h-5 text-[#ff8555] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <p class="text-sm text-[#8a5a3b]">{{ __('announcements.announcements_posted_info') }}</p>
    </div>
@endif

<div class="space-y-4">
    @forelse($announcements as $announcement)
        @php
            $canRemove = $announcement->author_id === auth()->id()
                || in_array(auth()->user()->role, ['super_admin'], true);
            $authorName = $announcement->author?->full_name ?? __('announcements.removed_account');
        @endphp
        <article class="bg-white rounded-xl shadow-sm p-6">
            <div class="flex items-start gap-4">
                <div class="w-10 h-10 bg-[#ff8555] rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    {{ strtoupper(substr($authorName, 0, 1)) }}
                </div>
                <div class="flex-1 min-w-0">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <h3 class="font-semibold text-[#182438]">{{ $announcement->title }}</h3>
                            <p class="text-xs text-[#8b949d] mt-1">
                                {{ $announcement->author?->full_name ?? 'Removed account' }}
                                @if($announcement->author)
                                    <span class="text-[#c9ced6]">&middot;</span>
                                    {{ ucfirst(str_replace('_', ' ', $announcement->author->role)) }}
                                @endif
                                <span class="text-[#c9ced6]">&middot;</span>
                                <time datetime="{{ $announcement->created_at?->toIso8601String() }}">{{ $announcement->created_at?->diffForHumans() }}</time>
                            </p>
                        </div>
                        @if($canRemove)
                            <form method="POST" action="{{ route('announcements.destroy', $announcement) }}"
                                onsubmit="return confirm('{{ __('announcements.remove_this_announcement') }}')"
                                class="flex-shrink-0">
                                @csrf @method('DELETE')
                                <button type="submit" title="{{ __('announcements.remove') }}"
                                    class="w-9 h-9 rounded-lg border border-[#ebe8e1] hover:bg-[#faf8f3] transition text-[#f05d56]">
                                    &times;
                                </button>
                            </form>
                        @endif
                    </div>
                    <p class="text-sm text-[#5f6873] mt-3 whitespace-pre-line">{{ $announcement->body }}</p>
                </div>
            </div>
        </article>
    @empty
        <div class="bg-white rounded-xl shadow-sm p-12 text-center">
            <svg class="w-12 h-12 mx-auto mb-4 text-[#ebe8e1]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>
            <p class="text-[#5f6873]">{{ __('announcements.no_announcements_yet') }}</p>
            @if($canPost)
                <a href="{{ route('announcements.create') }}" class="inline-block mt-4 text-[#ff8555] hover:text-[#f47548] font-medium text-sm">{{ __('announcements.post_the_first_one') }}</a>
            @endif
        </div>
    @endforelse
</div>
@endsection
